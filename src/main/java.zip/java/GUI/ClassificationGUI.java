package GUI;


import ij.IJ;
import ij.ImagePlus;
import ij.gui.Roi;

import java.awt.Rectangle;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

import segmentation.Segmentation;

public class ClassificationGUI {
	
	ArrayList<String> buttonNames;
	ArrayList<String> textList;
	Segmentation SegmentationObject;
	String inputDirectory;
	
	int beginFilesInInput;
	int beginIndex;
	
	public ClassificationGUI(Segmentation SegmentationObject, ArrayList<String> buttonNames, String inputDirectory) {
	this.buttonNames = buttonNames;
	this.SegmentationObject = SegmentationObject;
	this.inputDirectory = inputDirectory;
	}

	public void exec() {

		FunWithButtons FunWithButtonsObject = new FunWithButtons(buttonNames);
		Action ActionObject = new Action("lala");
		
		String[] myListSources1 = new File(inputDirectory).list();
		java.util.Arrays.sort(myListSources1);
		if (myListSources1==null) return;
		
		String filePath = inputDirectory + "Morph.txt";
		boolean backwards = false;
	
		myListSources1 = LoadProgress(myListSources1);
											
		if (beginFilesInInput < 0){
			beginFilesInInput = 0;
		}
		for (int filesInInput = beginFilesInInput; filesInInput < myListSources1.length; filesInInput++) {

			ImagePlus imp = IJ.openImage(inputDirectory+myListSources1[filesInInput]);

			SegmentationObject.exec(imp);
			
			Roi[] roiArray = SegmentationObject.getRoiArray();


			imp.setRoi(roiArray[0], true);
			imp.show();
			
			if (backwards == true){
				beginIndex = roiArray.length - 1;
				backwards = false;
			}
			else if (backwards == false && filesInInput == beginFilesInInput){
				beginIndex = beginIndex + 1;
				
			}
			else if (backwards == false && filesInInput != beginFilesInInput){
				beginIndex = 0;
			}
			
			FunWithButtonsObject.setVisible(true);
			for (int index=beginIndex; index < roiArray.length; index++) {
				imp.setRoi(roiArray[index], true);
				boolean waitForUserInput = true;
				boolean goBack = false;
				boolean stopExec = false;
				while(waitForUserInput == true && goBack == false && stopExec == false){
					waitForUserInput = ActionObject.getWaitForUserInput();
					goBack = ActionObject.getGoBack();
					stopExec  = ActionObject.getStopExec();
					try {
						Thread.sleep(100);
						} 
					catch (InterruptedException ex) {
						System.out.println("Error! :(");
						}
					}
				if (stopExec == true){
					filesInInput = myListSources1.length;
					break;
				}
				
				else if (waitForUserInput == false){
					
					Rectangle rect = roiArray[index].getBounds();
	
					textList.add(myListSources1[filesInInput] + ";" 
							+ Integer.toString(index) + ";" 
							+ Integer.toString(rect.height) + ";"
							+ Integer.toString(rect.width) + ";" 
							+ Integer.toString(rect.x) + ";" 
							+ Integer.toString(rect.y) + ";" 
							+ Integer.toString(ActionObject.getPressedButton()) 
							+ ";" + "\r\n");
	
				}
				
				else if (goBack == true){
					
					if (filesInInput > 0){
						
						if (index == 0){
							index = roiArray.length;
							filesInInput = filesInInput - 2;
							backwards = true;
							textList.remove(textList.size() - 1);
						}
						else if (index != 0){
							
							index = index - 2;
							textList.remove(textList.size() - 1);
						}
					}
					else{
						if (index != 0){
							
							index = index - 2;
							textList.remove(textList.size() - 1);
						}
					}
					
				}
				try {
					FileWriter fstreamAdd = new FileWriter(filePath , false);
					BufferedWriter outAdd = new BufferedWriter(fstreamAdd);
					for( int i = 0 ; i < textList.size() ; i++){
						outAdd.write(textList.get(i));
					}
					outAdd.close();
						
				} 
				catch (IOException e1) {
					stop();
				}

			}
			FunWithButtonsObject.setVisible(false);
			imp.changes = false;
			imp.close();

			
			

		}
		

	}
	


	
	private String[] LoadProgress(String[] myListSources1) {
		
		String myDir2 = inputDirectory;
		textList = new ArrayList<String>();
		String[] myListSources2 = new File(myDir2).list();
		beginIndex = -1;
		beginFilesInInput = -1;
		
		
		for(int i = 0 ; i < myListSources2.length ; i++){
			String fileName = myListSources2[i];
			if (fileName.indexOf("Morph.txt") >= 0){
				
				String previousImage = "";
				String currentImage;
				
				try{
					FileInputStream fstream = new FileInputStream(myDir2 + "Morph.txt");
					DataInputStream in = new DataInputStream(fstream);
					BufferedReader br = new BufferedReader(new InputStreamReader(in));
					String strLine;
					while ((strLine = br.readLine()) != null)   {
						int position = strLine.indexOf(";");
						currentImage = strLine.substring(0, position);
						beginIndex = Integer.parseInt(strLine.substring(position + 1, strLine.indexOf(";",position + 1)));
						textList.add(strLine + "\r\n");
						if (previousImage.indexOf(currentImage) < 0){
							beginFilesInInput = beginFilesInInput + 1;
						}
						previousImage = currentImage;
					}
				}
				catch (Exception e){
					  System.err.println("Error: " + e.getMessage());
				}
				
				
			}
		}

		int k = 0;
		for(int i = 0 ; i < myListSources1.length ; i++){
			if (myListSources1[i].indexOf(".tif") > 0 || myListSources1[i].indexOf(".dcm") > 0 || myListSources1[i].indexOf(".fits") > 0 ||
					myListSources1[i].indexOf(".fit") > 0 || myListSources1[i].indexOf(".fts") > 0 || myListSources1[i].indexOf(".pgm") > 0 || 
					myListSources1[i].indexOf(".jpg") > 0 || myListSources1[i].indexOf(".jpeg") > 0 || myListSources1[i].indexOf(".bmp") > 0){
				k = k + 1;
			}
			else{
				myListSources1[i] = "";
			}
		}
		int j = 0;
		String[] myListSources3 = new String[k];
		for(int i = 0 ; i < myListSources1.length ; i++){
			if (myListSources1[i] != ""){
				myListSources3[i - j] = myListSources1[i];
			}
			else{
				j = j + 1;
			}
		}
		return  myListSources3;
	}



	public void stop(){
		System.exit(0);
	}
	
	


	

}
