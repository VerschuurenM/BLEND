package GUI;

import java.awt.Container;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;

import java.util.ArrayList;
import java.util.List;

import javax.swing.*;


public class FunWithButtons extends JFrame
{
    private static List<JButton> buttons;
    private static List<String> buttonNames; 
    
    
    public FunWithButtons( List<String> buttonList )
    {
        super( "Fun with buttons..." );
        
        buttonNames = buttonList;
        
        setDefaultCloseOperation( DISPOSE_ON_CLOSE );
        
        Container pane = getContentPane();
        pane.setLayout( new GridLayout( buttonList.size() + 2, 1 ) );
        
        buttons = new ArrayList<JButton>( buttonNames.size() );        
        
        for ( int i = 0; i < buttonNames.size() ; i++ )
        {
            JButton button = new JButton( new Action( buttonNames.get(i) )  );
            button.setMnemonic(i);
            button.setName(buttonNames.get(i));
            //button.setPreferredSize(new Dimension(40, 40));
            pane.add( button );
            // Remember buttons in collection, we might need to access them sometime
            buttons.add( button );
            
        }
        JButton buttonBack = new JButton( new Action( "Go Back" )  );
        buttonBack.setMnemonic(buttonNames.size());
        buttonBack.setName("Go Back");
        pane.add( buttonBack );
        // Remember buttons in collection, we might need to access them sometime
        buttons.add( buttonBack );
        
        JButton buttonQuit = new JButton( new Action( "Quit" )  );
        buttonQuit.setMnemonic(buttonNames.size() + 1);
        buttonQuit.setName("Quit");
        pane.add( buttonQuit );
        // Remember buttons in collection, we might need to access them sometime
        buttons.add( buttonQuit );
        
        
        pack();
        
    }
    

    
    public static List<JButton> getButtons(){
    	return buttons;
    }
}

class Action extends AbstractAction{
	
	private static boolean waitForUserInput = true;
	private static boolean goBack;// = false;
	private static int pressedButton;
	private static boolean stopExec;
	
    public Action( String text )
    {
        super( text );
    }
    
    public void actionPerformed( ActionEvent e )
    {
    	List<JButton> buttons = FunWithButtons.getButtons();

    	for(int i = 0 ; i < buttons.size() ; i++){

    		
    		if( buttons.get(i).getName().indexOf((String)getValue(javax.swing.Action.NAME)) == 0 && getValue(javax.swing.Action.NAME).toString().length() == buttons.get(i).getName().length()){
    			pressedButton =  i;
    			i = buttons.size();
    			waitForUserInput = false;
    		}
    		else if( buttons.get(buttons.size() - 1).getName().indexOf((String)getValue(javax.swing.Action.NAME)) == 0 && getValue(javax.swing.Action.NAME).toString().length() == buttons.get(buttons.size() - 1).getName().length()){
    			stopExec = true;
        		i = buttons.size();
        	}
        	else if( buttons.get(buttons.size() - 2).getName().indexOf((String)getValue(javax.swing.Action.NAME)) == 0 && getValue(javax.swing.Action.NAME).toString().length() == buttons.get(buttons.size() - 2).getName().length()){
        		goBack = true;        		
        		System.out.println("vorige");
        		i = buttons.size();
        	}
    	}
    	
    	

    }
    public boolean getWaitForUserInput(){
    	boolean waitForUserInputReturn = waitForUserInput;
    	waitForUserInput = true;
    	
		return waitForUserInputReturn;
	}
    public int getPressedButton(){
    	return pressedButton;
    }

	public boolean getGoBack() {
		boolean goBackReturn = goBack;
		goBack = false;
		
		return goBackReturn;
	}

	public boolean getStopExec() {
		boolean stopExecReturn = stopExec;
		stopExec = false;

		return stopExecReturn;
	}
}