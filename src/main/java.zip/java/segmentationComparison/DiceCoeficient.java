package segmentationComparison;

import java.awt.Component;
import java.awt.Polygon;
import java.io.File;

import ij.gui.Roi;
import ij.plugin.*;
import ij.IJ;
import ij.ImagePlus;
import ij.WindowManager;
import ij.plugin.frame.RoiManager;
import ij.process.FloatPolygon;
import ij.process.ImageProcessor;
import java.lang.Math;

/*
 * Object histogram, 
 * 2 parameters imp en treshold
 * methodes:
 * *exec
 */ 
public class DiceCoeficient {
	int similarityindex;
	int overlapindex;
	int extrafraction;

	public DiceCoeficient() {
	}

	public DiceCoeficient(int similarityIndex, int overlapIndex, int extraFraction) {
		this.similarityindex = similarityIndex;
		this.overlapindex = overlapIndex;
		this.extrafraction = extraFraction;
	}

	public int getSimilarityIndex() {
		return similarityindex;
	}

	public int getOverlapIndex() {
		return overlapindex;
	}
	
	public int getExtraFraction() {
		return extrafraction;
	}
	
	public void exec(ImagePlus impParameters, ImagePlus impGroundRule) {
		
		
		ImagePlus impSubtract = new ImageCalculator().run("Subtract create", impParameters, impGroundRule);
		ImagePlus impIntersection = new ImageCalculator().run("Subtract create", impParameters, impSubtract);
		
		int intersectionSurface = impIntersection.getStatistics().histogram[impIntersection.getStatistics().histogram.length - 1];
		int groundRuleSurface = impGroundRule.getStatistics().histogram[impGroundRule.getStatistics().histogram.length - 1];
		int parametersSurface = impParameters.getStatistics().histogram[impParameters.getStatistics().histogram.length - 1];
		int subtractSurface = impSubtract.getStatistics().histogram[impSubtract.getStatistics().histogram.length - 1];
                
                //TEST
                /*/
                impParameters.show();
                impGroundRule.show();
                impSubtract.show();
                impIntersection.show();
                System.out.println("");
                //*/
		
		int similarityIndex = 1000 * 2 * intersectionSurface / (groundRuleSurface + parametersSurface);
		int overlapIndex = 1000 * intersectionSurface / groundRuleSurface;
		int extraFraction = 1000 * subtractSurface / groundRuleSurface;
		
		this.similarityindex = similarityIndex;
		this.overlapindex = overlapIndex;
		this.extrafraction = extraFraction;


	}
	

}
