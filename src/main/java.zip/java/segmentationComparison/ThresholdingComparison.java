/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package segmentationComparison;

import ij.IJ;
import ij.ImagePlus;
import ij.gui.Roi;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import segmentation.Segmentation;

/**
 *
 * @author Marlies Verschuuren
 */
public class ThresholdingComparison {
    //protected Double[][] exec (Double[][] parameterArray)
    
    
    
}
