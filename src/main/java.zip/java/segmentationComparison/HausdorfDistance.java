package segmentationComparison;


import ij.IJ;
import ij.ImagePlus;
import ij.process.ImageProcessor;


/*
 * Object histogram, 
 * 2 parameters imp en treshold
 * methodes:
 * *exec
 */ 
public class HausdorfDistance {
	double hausdorfdistanceMax;
	double hausdorfdistanceSum;

	public HausdorfDistance() {
	}

	public HausdorfDistance(double hddSum, double hddMax) {
		this.hausdorfdistanceSum = hddSum;
		this.hausdorfdistanceMax = hddMax;
	}

	public double getHausDorfDistanceSum() {
		return hausdorfdistanceSum;
	}

	public double getHausDorfDistanceMax() {
		return hausdorfdistanceMax;
	}
	
	public void exec(ImagePlus impAlgorithm, ImagePlus impGroundTruth) {

		ImagePlus impParameters = impAlgorithm.duplicate();
		ImagePlus impGroundRule = impGroundTruth.duplicate();

		
		IJ.run(impParameters, "Invert", "");
		IJ.run(impGroundRule, "Invert", "");
		IJ.run(impParameters, "Outline", "");
		IJ.run(impGroundRule, "Outline", "");
		IJ.run(impParameters, "Invert", "");
		IJ.run(impGroundRule, "Invert", "");

		
		int pixelsGroundRule = impGroundRule.getStatistics().histogram[impGroundRule.getStatistics().histogram.length - 1];
		int pixelsParameters = impParameters.getStatistics().histogram[impParameters.getStatistics().histogram.length - 1];
		
		int height = impParameters.getHeight();
		int width = impParameters.getWidth();
		ImageProcessor ip = impParameters.getProcessor();
		int[][][] parameterRoiArray = new int[2][pixelsGroundRule][pixelsParameters];
		int i = 0;
		for (int y=height - 1; y>=0; y--) {
			for (int x=0; x<width; x++) {
				float v = ip.getPixelValue(x,y);
				if (v > 0){
					for (int j=0; j<pixelsGroundRule; j++){
						parameterRoiArray[0][j][i] = x;
					}
					for (int j=0; j<pixelsGroundRule; j++){
						parameterRoiArray[1][j][i] = y;
					}
					i++;
				}
			}
		}

		height = impGroundRule.getHeight();
		width = impGroundRule.getWidth();
		ip = impGroundRule.getProcessor();
		int[][][] GroundRuleRoiArray = new int[2][pixelsGroundRule][pixelsParameters];
		i = 0;
		for (int y=height - 1; y>=0; y--) {
			for (int x=0; x<width; x++) {
				float v = ip.getPixelValue(x,y);
				if (v > 0){
					for (int j=0; j<pixelsParameters; j++){
						//System.out.println(Integer.toString(j));
						GroundRuleRoiArray[0][i][j] = x;
					}
					for (int j=0; j<pixelsParameters; j++){
						GroundRuleRoiArray[1][i][j] = y;
					}
					i++;
				}
			}
		}
		double[][] D = new double[pixelsGroundRule][pixelsParameters];
		for ( i=0;i <pixelsGroundRule; i++){
			for (int j=0; j <pixelsParameters; j++){
				double realPart = java.lang.Math.pow(GroundRuleRoiArray[0][i][j] - parameterRoiArray[0][i][j],2);
				double imPart = java.lang.Math.pow(GroundRuleRoiArray[1][i][j] - parameterRoiArray[1][i][j],2);
				D[i][j] = java.lang.Math.sqrt(realPart + imPart);
			}
		}
		
		
		double[] minE = new double[pixelsGroundRule];
		for ( i=0;i <pixelsGroundRule; i++){
			minE[i] = D[i][0];
			for (int j=0; j <pixelsParameters; j++){
				if (minE[i]> D[i][j]) {
					minE[i]= D[i][j];
				}
			}
		}
		double maxminE;
		double summinE;
		summinE = 0;
		maxminE = minE[0];
		for ( i=0;i <pixelsGroundRule; i++){
			summinE = summinE +minE[i];
			if (maxminE < minE[i]) {
				maxminE = minE[i];
				
			}
		}
		summinE = summinE/pixelsGroundRule;
				
		double[] minF = new double[pixelsParameters];
		for ( int j=0;j <pixelsParameters; j++){
			minF[j] = D[0][j];
			for (i=0; i <pixelsGroundRule; i++){
				if (minF[j]> D[i][j]) {
					minF[j]= D[i][j];
				}
			}
		}
		
		double maxminF;
		double summinF;
		summinF = 0;
		maxminF = minF[0];
		for ( i=0;i <pixelsParameters; i++){
			summinF = summinF +minF[i];
			if (maxminF < minF[i]) {
				maxminF = minF[i];
				
			}
		}
		summinF = summinF/pixelsParameters;
		
		
		double hddMax;
		if (maxminE > maxminF) {
			hddMax = maxminE;
		}
		else {
			hddMax = maxminF;
		}
		
		double hddSum;
		if (summinE > summinF) {
			hddSum = summinE;
		}
		else {
			hddSum = summinF;
		}
		
		D = null;
		parameterRoiArray = null;
		GroundRuleRoiArray = null;
		minE = null;
		minF = null;
		
		this.hausdorfdistanceMax = hddMax;
		this.hausdorfdistanceSum = hddSum;


	}
	

}
