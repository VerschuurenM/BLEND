package segmentationComparison;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import segmentation.Segmentation;

import ij.IJ;
import ij.ImagePlus;
import ij.gui.NewImage;
import ij.gui.Roi;
import ij.io.Opener;
import ij.io.RoiDecoder;
import ij.measure.Measurements;
import ij.measure.ResultsTable;
import ij.plugin.ImageCalculator;
import ij.plugin.filter.Analyzer;
import ij.plugin.frame.RoiManager;
import ij.process.FloatPolygon;
import ij.process.ImageProcessor;
import initialConfiguration.InitialConfiguration;

public class SegmentationComparisonNegCtrl {

    double[] similarityIndexImageArray;
    double[] overlapIndexImageArray;
    double[] extraFractionImageArray;
    double[] hddMaxImageArray;
    double[] hddSumImageArray;
    int amountOfRois;

    public void exec(ArrayList<Roi> roiList) {
            int totalRois=roiList.size();
            HausdorfDistance HDD = new HausdorfDistance();
            DiceCoeficient DC = new DiceCoeficient();
            ImagePlus imp = NewImage.createByteImage("Test", 1280, 1024, 0, 0);
            int centerImageX= Math.round(imp.getWidth()/2);
            int centerImageY= Math.round(imp.getHeight()/2);
            Analyzer.setMeasurements(0);
            int measurements = Measurements.CENTER_OF_MASS;
            Analyzer.setMeasurements(measurements);
            ImagePlus[] impMaskArray = new ImagePlus[totalRois];
             
            for (int i=0; i<roiList.size(); i++){
                Roi roi = roiList.get(i);
                ImagePlus test=createMask(roi);
                //test.show();
                ResultsTable rt = new ResultsTable();
                Analyzer analyzer = new Analyzer(imp, measurements, rt);
                imp.show();
                imp.setRoi(roi);
                analyzer.measure();
                imp.killRoi();
                FloatPolygon interpolatedRoi = roi.getInterpolatedPolygon(5, true);
                float[] coordX = interpolatedRoi.xpoints;
                float[] coordY = interpolatedRoi.ypoints;
                double minX = imp.getWidth();
                double minY = imp.getHeight();
                for(int j=0; j<coordX.length;j++){
                    if(coordX[j]<minX){
                        minX = (double)(coordX[j]);
                    }
                    if(coordY[j]<minY){
                        minY = (double)(coordY[j]);
                    }
                }
                double centerX = rt.getValueAsDouble(ResultsTable.X_CENTER_OF_MASS, 0);
                double centerY = rt.getValueAsDouble(ResultsTable.Y_CENTER_OF_MASS, 0);
                roi.setLocation(centerImageX-(centerX-minX),centerImageY-(centerY-minY));
                impMaskArray[i] = createMask(roi);
                //impMaskArray[i].show();
            }
             
                similarityIndexImageArray = new double[(totalRois)*(totalRois-1)];
                overlapIndexImageArray = new double[(totalRois)*(totalRois-1)];
                extraFractionImageArray = new double[(totalRois)*(totalRois-1)];
                hddMaxImageArray = new double[(totalRois)*(totalRois-1)];
                hddSumImageArray = new double[(totalRois)*(totalRois-1)];
                int index=0;
                
                for (int i = 0; i < totalRois; i++) {
                    System.out.println("Roi: " + i);
                    for (int j = 0; j < totalRois; j++) {
                        if(i!=j){
                            DC.exec(impMaskArray[i], impMaskArray[j]);
                            int similarityIndex = DC.getSimilarityIndex();
                            int overlapIndex = DC.getOverlapIndex();
                            int extraFraction = DC.getExtraFraction();

                            /* calculate hausdorf distance */
                            HDD.exec(impMaskArray[i], impMaskArray[j]);
                            double hddMax = HDD.getHausDorfDistanceMax();
                            double hddSum = HDD.getHausDorfDistanceSum();

                            similarityIndexImageArray[index] = (double) similarityIndex;
                            overlapIndexImageArray[index] = (double) overlapIndex;
                            extraFractionImageArray[index] = (double) extraFraction;
                            hddMaxImageArray[index] = hddMax;
                            hddSumImageArray[index] = hddSum;
                            System.out.println("Index: " + index);
                            index++;
                            
                }
            }
        }
    }

    private ImagePlus createMask(Roi roi) {

        ImagePlus impMask = IJ.createImage("Mask", "8-bit Black", 1280, 1024, 1);
        ImageProcessor ipMask = impMask.getProcessor();
        ipMask.setRoi(roi);
        ipMask.setValue(255);
        ipMask.fill(ipMask.getMask());
        impMask.updateAndDraw();

        return impMask;

    }

    private Roi[] getRoiGT(String groundThruthPath) {
        ArrayList<Roi> roiList = new ArrayList<Roi>();
        ZipInputStream in = null;
        ByteArrayOutputStream out;
        //int nRois = 0; 
        try {
            in = new ZipInputStream(new FileInputStream(groundThruthPath));
            byte[] buf = new byte[1024];
            int len;
            ZipEntry entry = in.getNextEntry();
            while (entry != null) {
                String name = entry.getName();
                if (name.endsWith(".roi")) {
                    out = new ByteArrayOutputStream();
                    while ((len = in.read(buf)) > 0) {
                        out.write(buf, 0, len);
                    }
                    out.close();
                    byte[] bytes = out.toByteArray();
                    RoiDecoder rd = new RoiDecoder(bytes, name);
                    Roi roi = rd.getRoi();
                    if (roi != null) {
                        roiList.add(roi);
                        //nRois++;
                    }
                }
                entry = in.getNextEntry();
            }
            in.close();
        } catch (IOException e) {
            System.out.println(e.toString());
        }
        Roi[] roiArrayGT = new Roi[roiList.size()];
        roiArrayGT = roiList.toArray(roiArrayGT);
        return roiArrayGT;

    }

    public double[] getSimilarityIndexImageArray() {
        return similarityIndexImageArray;
    }

    public double[] getOverlapIndexImageArray() {
        return overlapIndexImageArray;
    }

    public double[] getExtraFractionImageArray() {
        return extraFractionImageArray;
    }

    public double[] getHddMaxImageArray() {
        return hddMaxImageArray;
    }

    public double[] getHddSumImageArray() {
        return hddSumImageArray;
    }

    public int getAmountOfRois() {
        return amountOfRois;
    }
}
