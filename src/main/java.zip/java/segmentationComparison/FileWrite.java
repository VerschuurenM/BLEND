package segmentationComparison;
import java.io.*;
class FileWrite 
{
 public static void exec(String parameters, String GroundruleDirectory, String DirectoryName)
  {
  try{
  // Create file 
  FileWriter fstream = new FileWriter(GroundruleDirectory + DirectoryName +"parameters.txt", true);
  BufferedWriter out = new BufferedWriter(fstream);
  out.write(parameters);
  //Close the output stream
  out.close();
  }catch (Exception e){//Catch exception if any
  System.err.println("Error: " + e.getMessage());
  }
  }
}