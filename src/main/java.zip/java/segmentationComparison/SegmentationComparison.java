package segmentationComparison;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import segmentation.Segmentation;

import ij.IJ;
import ij.ImagePlus;
import ij.gui.Roi;
import ij.io.Opener;
import ij.io.RoiDecoder;
import ij.plugin.ImageCalculator;
import ij.plugin.frame.RoiManager;
import ij.process.ImageProcessor;
import initialConfiguration.InitialConfiguration;

public class SegmentationComparison {

    double[] similarityIndexImageArray;
    double[] overlapIndexImageArray;
    double[] extraFractionImageArray;
    double[] hddMaxImageArray;
    double[] hddSumImageArray;
    int amountOfRois;

    public void exec(Roi[] roiArrayImp, Roi[] roiArrayGT) {

        if (roiArrayImp.length > 0 && roiArrayGT.length > 0) {
            HausdorfDistance HDD = new HausdorfDistance();
            DiceCoeficient DC = new DiceCoeficient();

            /* LOAD GROUNDTRUTH */
            //IJ.log(Integer.toString(roiArrayImp.length));
            int impArrayLength = 0;
            ImagePlus[] impArray = new ImagePlus[roiArrayImp.length];
            for (int i = 0; i < roiArrayImp.length; i++) {
                if (roiArrayImp[i].getBounds().getWidth() * roiArrayImp[i].getBounds().getHeight() > 0) {
                    impArray[impArrayLength++] = CreateMask(roiArrayImp[i]);
                }
            }

            int GTArrayLength = 0;
            ImagePlus[] GTArray = new ImagePlus[roiArrayGT.length];
            for (int i = 0; i < roiArrayGT.length; i++) {
                if (roiArrayGT[i].getBounds().getWidth() * roiArrayGT[i].getBounds().getHeight() > 0) {
                    GTArray[GTArrayLength++] = CreateMask(roiArrayGT[i]);
                }
            }

            

            

            if (GTArrayLength >= impArrayLength) {
                similarityIndexImageArray = new double[GTArrayLength];
                overlapIndexImageArray = new double[GTArrayLength];
                extraFractionImageArray = new double[GTArrayLength];
                hddMaxImageArray = new double[GTArrayLength];
                hddSumImageArray = new double[GTArrayLength];
                amountOfRois = 0;
                for (int i = 0; i < GTArrayLength; i++) {
                    double countSimilarityCurrent = 0;
                    int intersectionRoi = 0;
                    for (int j = 0; j < impArrayLength; j++) {
                        /* compare groundtruth nucleus to algorithm nucleus */
                        ImagePlus impIntersection = new ImageCalculator().run("AND create", impArray[j], GTArray[i]);
                        int countImp = impArray[j].getStatistics().histogram[((int) impArray[j].getStatistics().histMax)];
                        int countIntersection = impIntersection.getStatistics().histogram[((int) impIntersection.getStatistics().histMax)];
                        int countGT = GTArray[i].getStatistics().histogram[((int) GTArray[i].getStatistics().histMax)];
                        double countSimilarity = (double) (2 * countIntersection) / (double) (countImp + countGT);
                        if (countSimilarity >= countSimilarityCurrent && countImp > 0) {
                            countSimilarityCurrent = countSimilarity;
                            intersectionRoi = j;
                        }
                    }
                    /* calculate dice coefficient */
                    DC.exec(impArray[intersectionRoi], GTArray[i]);
                    int similarityIndex = DC.getSimilarityIndex();
                    int overlapIndex = DC.getOverlapIndex();
                    int extraFraction = DC.getExtraFraction();

                    /* calculate hausdorf distance */
                    HDD.exec(impArray[intersectionRoi], GTArray[i]);
                    double hddMax = HDD.getHausDorfDistanceMax();
                    double hddSum = HDD.getHausDorfDistanceSum();

                    similarityIndexImageArray[i] = (double) similarityIndex;
                    overlapIndexImageArray[i] = (double) overlapIndex;
                    extraFractionImageArray[i] = (double) extraFraction;
                    hddMaxImageArray[i] = hddMax;
                    hddSumImageArray[i] = hddSum;

                    amountOfRois += 1;
                }
            }
            else{
                similarityIndexImageArray = new double[impArrayLength];
                overlapIndexImageArray = new double[impArrayLength];
                extraFractionImageArray = new double[impArrayLength];
                hddMaxImageArray = new double[impArrayLength];
                hddSumImageArray = new double[impArrayLength];
                amountOfRois = 0;
                for (int i = 0; i < impArrayLength; i++) {
                    double countSimilarityCurrent = 0;
                    int intersectionRoi = 0;

                    for (int j = 0; j < GTArrayLength; j++) {
                        /* compare groundtruth nucleus to algorithm nucleus */
                        ImagePlus impIntersection = new ImageCalculator().run("AND create", impArray[i], GTArray[j]);
                        int countImp = impArray[i].getStatistics().histogram[((int) impArray[i].getStatistics().histMax)];
                        int countIntersection = impIntersection.getStatistics().histogram[((int) impIntersection.getStatistics().histMax)];
                        int countGT = GTArray[j].getStatistics().histogram[((int) GTArray[j].getStatistics().histMax)];
                        double countSimilarity = (double) (2 * countIntersection) / (double) (countImp + countGT);
                        if (countSimilarity >= countSimilarityCurrent && countImp > 0) {
                            //TEST
                            //impIntersection.show();
                            countSimilarityCurrent = countSimilarity;
                            intersectionRoi = j;      
                        }
                    }
                    
                    //TEST
                    //impArray[i].show();
                    //GTArray[intersectionRoi].show();
                    /* calculate dice coefficient */
                    DC.exec(impArray[i], GTArray[intersectionRoi]);
                    int similarityIndex = DC.getSimilarityIndex();
                    int overlapIndex = DC.getOverlapIndex();
                    int extraFraction = DC.getExtraFraction();

                    /* calculate hausdorf distance */
                    HDD.exec(impArray[i], GTArray[intersectionRoi]);
                    double hddMax = HDD.getHausDorfDistanceMax();
                    double hddSum = HDD.getHausDorfDistanceSum();

                    similarityIndexImageArray[i] = (double) similarityIndex;
                    overlapIndexImageArray[i] = (double) overlapIndex;
                    extraFractionImageArray[i] = (double) extraFraction;
                    hddMaxImageArray[i] = hddMax;
                    hddSumImageArray[i] = hddSum;

                    amountOfRois += 1;
                }
            }
        }

    }

    private String getMethod(int myMethod) {
        String myMethodString;

        if (myMethod == 1) {
            myMethodString = "Huang";
        } else if (myMethod == 2) {
            myMethodString = "Intermodes";
        } else if (myMethod == 3) {
            myMethodString = "IsoData";
        } else if (myMethod == 4) {
            myMethodString = "Li";
        } else if (myMethod == 5) {
            myMethodString = "MaxEntropy";
        } else if (myMethod == 6) {
            myMethodString = "Mean";
        } else if (myMethod == 7) {
            myMethodString = "MinErrorI";
        } else if (myMethod == 8) {
            myMethodString = "Minimum";
        } else if (myMethod == 9) {
            myMethodString = "Otsu";
        } else if (myMethod == 10) {
            myMethodString = "Triangle";
        } else if (myMethod == 11) {
            myMethodString = "Yen";
        } else if (myMethod == 12) {
            myMethodString = "Moments";
        } else if (myMethod == 13) {
            myMethodString = "Percentile";
        } else if (myMethod == 14) {
            myMethodString = "Shanbhag";
        } else {
            myMethodString = "No Method";
        }
        return myMethodString;
    }

    private ImagePlus CreateMask(Roi roi) {

        ImagePlus impMask = IJ.createImage("Mask", "8-bit Black", 1280, 1024, 1);
        ImageProcessor ipMask = impMask.getProcessor();
        ipMask.setRoi(roi);
        ipMask.setValue(255);
        ipMask.fill(ipMask.getMask());
        impMask.updateAndDraw();

        return impMask;

    }

    private Roi[] getRoiGT(String groundThruthPath) {
        ArrayList<Roi> roiList = new ArrayList<Roi>();
        ZipInputStream in = null;
        ByteArrayOutputStream out;
        //int nRois = 0; 
        try {
            in = new ZipInputStream(new FileInputStream(groundThruthPath));
            byte[] buf = new byte[1024];
            int len;
            ZipEntry entry = in.getNextEntry();
            while (entry != null) {
                String name = entry.getName();
                if (name.endsWith(".roi")) {
                    out = new ByteArrayOutputStream();
                    while ((len = in.read(buf)) > 0) {
                        out.write(buf, 0, len);
                    }
                    out.close();
                    byte[] bytes = out.toByteArray();
                    RoiDecoder rd = new RoiDecoder(bytes, name);
                    Roi roi = rd.getRoi();
                    if (roi != null) {
                        roiList.add(roi);
                        //nRois++;
                    }
                }
                entry = in.getNextEntry();
            }
            in.close();
        } catch (IOException e) {
            System.out.println(e.toString());
        }
        Roi[] roiArrayGT = new Roi[roiList.size()];
        roiArrayGT = roiList.toArray(roiArrayGT);
        return roiArrayGT;

    }

    public double[] getSimilarityIndexImageArray() {
        return similarityIndexImageArray;
    }

    public double[] getOverlapIndexImageArray() {
        return overlapIndexImageArray;
    }

    public double[] getExtraFractionImageArray() {
        return extraFractionImageArray;
    }

    public double[] getHddMaxImageArray() {
        return hddMaxImageArray;
    }

    public double[] getHddSumImageArray() {
        return hddSumImageArray;
    }

    public int getAmountOfRois() {
        return amountOfRois;
    }
}
