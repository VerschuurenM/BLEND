package initialConfiguration;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import javax.swing.JFileChooser;

public class InitialConfiguration {

    String inputDirectory;
    String outputDirectory;

    boolean smoothing;
    boolean watershed;
    int numberThreshold;
    int globalThresholdMethod;
    int localThresholdMethod;
    int dilations;
    int functionality;
    int curvature;
    int fourier;
    int gradients;
    int moments;

    ArrayList<String> GTDirectory;
    ArrayList<String> buttonNames;

    public InitialConfiguration() {

        String fileName = UserDialog();

        try {
            FileInputStream fstream = new FileInputStream(fileName);
            DataInputStream in = new DataInputStream(fstream);
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            String strLine;
            buttonNames = new ArrayList<String>();
            GTDirectory = new ArrayList<String>();

            while ((strLine = br.readLine()) != null) {

                strLine = strLine.trim();
                String strLineLC = strLine.toLowerCase();
                String measureLength;

                if (strLineLC.indexOf("input directory:") >= 0) {
                    measureLength = "input directory:";
                    this.inputDirectory = strLine.substring(measureLength.length()).replaceAll("\\\\", "\\\\\\\\").trim();
                } else if (strLineLC.indexOf("output directory:") >= 0) {
                    measureLength = "output directory:";
                    this.outputDirectory = strLine.substring(measureLength.length()).replaceAll("\\\\", "\\\\\\\\").trim();
                } else if (strLineLC.indexOf("global thresholding method:") >= 0) {
                    try {
                        measureLength = "global thresholding method:";
                        this.globalThresholdMethod = Integer.parseInt(strLine.substring(measureLength.length()).trim());
                    } catch (NumberFormatException e) {
                        System.err.println("Global Thresholding Method was not an Integer. Error: " + e.getMessage());
                        Stop();
                    }
                } else if (strLineLC.indexOf("local thresholding method:") >= 0) {
                    try {
                        measureLength = "local thresholding method:";
                        this.localThresholdMethod = Integer.parseInt(strLine.substring(measureLength.length()).trim());
                    } catch (NumberFormatException e) {
                        System.err.println("Local Thresholding Method was not an Integer. Error: " + e.getMessage());
                        Stop();
                    }
                } else if (strLineLC.indexOf("amount of dilations:") >= 0) {
                    try {
                        measureLength = "amount of dilations:";
                        this.dilations = Integer.parseInt(strLine.substring(measureLength.length()).trim());
                    } catch (NumberFormatException e) {
                        System.err.println("Amount Of Dilations was not an Integer. Error: " + e.getMessage());
                        Stop();
                    }
                } else if (strLineLC.indexOf("functionality:") >= 0) {
                    try {
                        measureLength = "functionality:";
                        this.functionality = Integer.parseInt(strLine.substring(measureLength.length()).trim());
                    } catch (NumberFormatException e) {
                        System.err.println("Functionality was not an Integer. Error: " + e.getMessage());
                        Stop();
                    }
                } else if (strLineLC.indexOf("curvature range:") >= 0) {
                    try {
                        measureLength = "curvature range:";
                        this.curvature = Integer.parseInt(strLine.substring(measureLength.length()).trim());
                    } catch (NumberFormatException e) {
                        System.err.println("Curvature Range was not an Integer. Error: " + e.getMessage());
                        Stop();
                    }
                } else if (strLineLC.indexOf("fourier descriptors:") >= 0) {
                    try {
                        measureLength = "fourier descriptors:";
                        this.fourier = Integer.parseInt(strLine.substring(measureLength.length()).trim());
                    } catch (NumberFormatException e) {
                        System.err.println("Fourier Descriptors was not an Integer. Error: " + e.getMessage());
                        Stop();
                    }
                } else if (strLineLC.indexOf("order of moments:") >= 0) {
                    try {
                        measureLength = "order of moments:";
                        this.moments = Integer.parseInt(strLine.substring(measureLength.length()).trim());
                    } catch (NumberFormatException e) {
                        System.err.println("Order Of Moments was not an Integer. Error: " + e.getMessage());
                        Stop();
                    }
                } else if (strLineLC.indexOf("gradient range:") >= 0) {
                    try {
                        measureLength = "gradient range:";
                        this.gradients = Integer.parseInt(strLine.substring(measureLength.length()).trim());
                    } catch (NumberFormatException e) {
                        System.err.println("Gradient Range was not an Integer. Error: " + e.getMessage());
                        Stop();
                    }
                } else if (strLineLC.indexOf("class:") >= 0) {
                    measureLength = "class:";
                    this.buttonNames.add(strLine.substring(measureLength.length()).trim());
                } else if (strLineLC.indexOf("ground truth directory:") >= 0) {
                    measureLength = "ground truth directory:";
                    this.GTDirectory.add(strLine.substring(measureLength.length()).replaceAll("\\\\", "\\\\\\\\").trim());
                } else if (strLineLC.indexOf("smoothing:") >= 0) {
                    measureLength = "smoothing:";
                    try {
                        if (strLineLC.indexOf("yes") >= 0) {
                            smoothing = true;
                        } else if (strLineLC.indexOf("no") >= 0) {
                            smoothing = false;
                        }
                    } catch (NumberFormatException e) {
                        System.err.println("Smoothing has to be yes/no. Error: "  + e.getMessage());
                        Stop();
                    }
                } else if (strLineLC.indexOf("watershed:") >= 0) {
                    measureLength = "Watershed:";
                    try {
                        if (strLineLC.indexOf("yes") >= 0) {
                            watershed = true;
                        } else if (strLineLC.indexOf("no") >= 0) {
                            watershed = false;
                        }
                    } catch (NumberFormatException e) {
                        System.err.println("Watershed has to be yes/no. Error: " + e.getMessage());
                        Stop();
                    }
                }
                else if (strLineLC.indexOf("number threshold:") >= 0) {
                    try {
                        measureLength = "number threshold:";
                        this.numberThreshold = Integer.parseInt(strLine.substring(measureLength.length()).trim());
                    } catch (NumberFormatException e) {
                        System.err.println("numberThreshold was not an Integer. Error: " + e.getMessage());
                        Stop();
                    }
                } 
                else {
                    System.err.println("Unknown property in Config File: " + strLine);

                }
            }
            in.close();
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            Stop();
        }
    }

    private String UserDialog() {
        String directory = System.getProperty("user.dir");
        JFileChooser fileChooser = new JFileChooser(directory);
        int rc = fileChooser.showDialog(null, "Select Configuration File");
        String fileName;
        if (rc == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            fileName = file.getAbsolutePath();
        } else {
            System.out.println("File chooser cancel button clicked");
            Stop();
            fileName = null;
        }

        return fileName;
    }

    private void Stop() {
        System.exit(0);

    }

    public String getInputDirectory() {
        return inputDirectory;
    }

    public String getOutputDirectory() {
        return outputDirectory;
    }

    public int getGlobalThresholdMethod() {
        return globalThresholdMethod;
    }

    public int getLocalThresholdMethod() {
        return localThresholdMethod;
    }

    public int getDilations() {
        return dilations;
    }

    public int getFunctionality() {
        return functionality;
    }

    public ArrayList<String> getButtonNames() {
        return buttonNames;
    }

    public ArrayList<String> getGTDirectory() {
        return GTDirectory;
    }

    public int getCurvature() {
        return curvature;
    }

    public int getFourier() {
        return fourier;
    }

    public int getGradients() {
        return gradients;
    }

    public int getMoments() {
        return moments;
    }
    public int getNumberThreshold() {
        return numberThreshold;
    }
    public boolean getSmoothing() {
        return smoothing;
    }
    public boolean getWatershed() {
        return watershed;
    }


}
