/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package segmentation;

import java.util.ArrayList;
import ij.gui.Roi;
import ij.ImagePlus;
import java.awt.Rectangle;
import ij.gui.PolygonRoi;
import ij.measure.Measurements;
import ij.measure.ResultsTable;
import ij.plugin.filter.Analyzer;
import java.awt.Polygon;
import java.util.Arrays;

/**
 *
 * @author marliesverschuuren
 */
public class RemoveRoiEdge {

    protected ArrayList<Roi> exec(ImagePlus imp, ArrayList<Roi> roiList) {
        int impWidth = imp.getWidth();
        int impHeight = imp.getHeight();
        ArrayList<Roi> roiListCheckedEdge = new ArrayList<Roi>();

        for (int i = 0; i < roiList.size(); i++) {
            Rectangle boundingRect = roiList.get(i).getBounds();
            if (boundingRect.getWidth() + boundingRect.x < impWidth - 1
                    && boundingRect.getHeight() + boundingRect.y < impHeight - 1
                    && boundingRect.x > 0
                    && boundingRect.y > 0) {
                roiListCheckedEdge.add(roiList.get(i));
            }
        }
        return roiListCheckedEdge;
    }
}
