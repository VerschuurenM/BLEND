package segmentation;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.awt.Color;
import java.util.ArrayList;
/**
 *
 * @author Marlies Verschuuren
 */

public class getColor {
    public Color exec (int i)
    {
        ArrayList<Color> colorList = colorList();
        if(i>colorList.size()-1)
        {
            while (i>colorList.size()-1)    
            {
                i=i-colorList.size();
            }
            Color color = colorList.get(i);
            return color;
        }
        else{
            Color color = colorList.get(i);
            return color;
        }
        
        
    }
    protected ArrayList<Color> colorList()
    {
        ArrayList<Color> colorList = new ArrayList<Color>();
        colorList.add(Color.red);
        colorList.add(Color.BLUE);
        colorList.add(Color.CYAN);
        colorList.add(Color.GREEN);
        colorList.add(Color.MAGENTA);
        colorList.add(Color.ORANGE);
        colorList.add(Color.PINK);
        colorList.add(Color.YELLOW);
        return colorList;
    }
    
}
