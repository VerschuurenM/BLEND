/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package segmentation;

import ij.ImagePlus;
import ij.gui.Overlay;
import ij.gui.Roi;
import ij.plugin.Duplicator;
import ij.plugin.frame.RoiManager;
import ij.process.ImageProcessor;
import java.util.ArrayList;
import java.awt.Color;

/**
 *
 * @author Marlies Verschuuren
 */
public class TestImage {

    ImagePlus impTest = new ImagePlus();

    protected void execRoiList(ImagePlus imp, ArrayList<Roi> roiList, String title, Color color) {
        Overlay overlay = new Overlay();
        impTest = imp.duplicate();
        for (int i = 0; i < roiList.size(); i++) {
            roiList.get(i).setStrokeColor(color);
            overlay.add(roiList.get(i));
        }
        impTest.setOverlay(overlay);
        impTest.setTitle(title);
        impTest.show();
    }

    protected void execRoiArray(ImagePlus imp, Roi[] roiArray, String title) {
        Overlay overlay = new Overlay();
        impTest = imp.duplicate();
        for (int i = 0; i < roiArray.length; i++) {
            //roiArray[i].setStrokeColor(color);
            overlay.add(roiArray[i]);
        }
        impTest.setOverlay(overlay);
        impTest.setTitle(title);
        impTest.show();
    }

    protected void execRoiArrayDiffColor(ImagePlus imp, Roi[] roiArray, String title) {
        Overlay overlay = new Overlay();
        impTest = imp.duplicate();
        getColor gC = new getColor();
        for (int i = 0; i < roiArray.length; i++) {
            Color color = gC.exec(i);
            roiArray[i].setStrokeColor(color);
            roiArray[i].setStrokeWidth(3.0);
            overlay.add(roiArray[i]);
        }
        impTest.setOverlay(overlay);
        impTest.setTitle(title);
        impTest.show();
    }
    protected void execRoiListDiffColor(ImagePlus imp, ArrayList<Roi> roiList, String title) {
        Overlay overlay = new Overlay();
        impTest = imp.duplicate();
        getColor gC = new getColor();
        for (int i = 0; i < roiList.size(); i++) {
            Color color = gC.exec(i);
            roiList.get(i).setStrokeColor(color);
            //roiList.get(i).setStrokeWidth(3.0);
            overlay.add(roiList.get(i));
        }
        impTest.setOverlay(overlay);
        impTest.setTitle(title);
        impTest.show();
    }

    protected ImagePlus getImage() {
        return impTest;
    }
}
