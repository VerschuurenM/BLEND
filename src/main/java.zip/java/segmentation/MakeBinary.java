/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package segmentation;

import ij.IJ;
import ij.ImagePlus;
import java.awt.Color;
import java.util.ArrayList;
import ij.gui.Roi;

/**
 *
 * @author Marlies Verschuuren
 */
public class MakeBinary {
    protected ImagePlus execList (int impWidth, int impHeight, ArrayList<Roi> roiList)
    {
        ImagePlus impBinary = IJ.createImage("impBinary", "8-bit black", impWidth, impHeight, 1);
        Color white = new Color(255, 255, 255);
        impBinary.getProcessor().setColor(white);
        for (int i=0; i<roiList.size();i++)
        {
                impBinary.getProcessor().fill(roiList.get(i));
            
        }
        //impBinary.show();
        return impBinary;
    }
    protected ImagePlus execArray (int impWidth, int impHeight, Roi[] roiArray)
    {
        ImagePlus impBinary = IJ.createImage("impBinary", "8-bit black", impWidth, impHeight, 1);
        Color white = new Color(255, 255, 255);
        impBinary.getProcessor().setColor(white);
        for (int i=0; i<roiArray.length;i++)
        {
            impBinary.getProcessor().fill(roiArray[i]);

        }
        //impBinary.show();
        return impBinary;
    }
    protected ImagePlus execRoi(int impWidth, int impHeight, Roi roi)
    {
        ImagePlus impBinary = IJ.createImage("impBinary", "8-bit black", impWidth, impHeight, 1);
        Color white = new Color(255, 255, 255);
        impBinary.getProcessor().setColor(white);
        impBinary.getProcessor().fill(roi);
        
        //impBinary.show();
        return impBinary;
    }
    
}
