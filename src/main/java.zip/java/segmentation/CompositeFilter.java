/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package segmentation;

import ij.ImagePlus;
import ij.gui.Roi;
import ij.gui.ShapeRoi;
import ij.plugin.Duplicator;
import java.awt.Color;
import java.awt.Rectangle;
import java.util.ArrayList;
import ij.plugin.Duplicator;

/**
 *
 * @author Marlies Verschuuren
 */
public class CompositeFilter {

    int impWidth;
    int impHeight;

    protected ArrayList<Roi> exec(ImagePlus imp, ArrayList<Roi> roiList) {
    //Some seperated ROIs are seen as one --> Split these combined ROIs
        
        impWidth = imp.getWidth();
        impHeight = imp.getHeight();
        
        ArrayList<Roi> roiListReturn = new ArrayList<Roi>();
        for (int roiNr = 0; roiNr < roiList.size(); roiNr++) {

            ShapeRoi roiCombinedShape = new ShapeRoi(roiList.get(roiNr));
            Roi[] roiArrayLocal = roiCombinedShape.getRois();
            
            ShapeRoi mainRoiShape = null;

            double maxLength = 0;
            //For loop over Combined Rois -> Search voor Roi with largest bounding rectangle
            //Set this Roi as main-Roi
            for (int i = 0; i < roiArrayLocal.length; i++) {
                if (roiArrayLocal[i].getLength() > maxLength && roiArrayLocal[i].getLength() > 10) {
                    maxLength = roiArrayLocal[i].getLength();
                    ShapeRoi maxShapeRoi = new ShapeRoi(roiArrayLocal[i]);
                    mainRoiShape = maxShapeRoi;
                }
            }

            //For loop over Combined Rois 
            //Perimeter >=15% maxLenght & < maxLength--> Add Seperate Roi to RoiList
            for (int i = 0; i < roiArrayLocal.length; i++) {
                    if (roiArrayLocal[i].getLength() >= maxLength / 100 * 15 && roiArrayLocal[i].getLength() < maxLength) {
                    roiListReturn.add(roiArrayLocal[i]);
                }
            }
            if (mainRoiShape != null) {
                roiListReturn.add(mainRoiShape);
            }
        }
        return roiListReturn;

    }

}
