package segmentation;

import ij.IJ;
import ij.ImagePlus;
import ij.gui.Overlay;
import ij.gui.Roi;
import ij.gui.ShapeRoi;
import ij.plugin.filter.ThresholdToSelection;
import ij.process.FloatStatistics;
import ij.process.ImageProcessor;
import ij.plugin.Duplicator;
import java.util.ArrayList;
import java.awt.Color;
import java.util.Arrays;
import ij.process.ImageConverter;

public class Segmentation {

    int globalThresholdMethod;
    int localThresholdMethod;
    int dilations;
    Roi[] roiArray;
    double[] measureFGBG;
    int numberThreshold;
    boolean smoothing;
    boolean watershed;
    boolean blackBackground;

    public Segmentation(int numberThreshold, int globalThresholdMethod, int localThresholdMethod, boolean smoothing, boolean watershed, int dilations, boolean blackBackground) {
        this.numberThreshold = numberThreshold;
        this.globalThresholdMethod = globalThresholdMethod;
        this.localThresholdMethod = localThresholdMethod;
        this.smoothing = smoothing;
        this.dilations = dilations;
        this.watershed = watershed;
        this.blackBackground = blackBackground;
    }

    public void exec(ImagePlus imp) {
        System.out.println("-------------------------------------");
        System.out.println("Image:" + imp.getTitle());
        long startTimeImage = System.currentTimeMillis();
        System.out.println(System.currentTimeMillis() - startTimeImage);

        //GradientRemoval
        //imp.show();
        GradientRemoval GR = new GradientRemoval(globalThresholdMethod);
        ImagePlus impWithoutGradient = GR.exec(imp, 3);
        //impWithoutGradient.show();
        System.out.println("GradientRemoval: " + (System.currentTimeMillis() - startTimeImage));

        ImagePlus impGlobal;
        if (smoothing == true) {
            //Smoothing
            ImagePlus impSmooth = new Duplicator().run(impWithoutGradient);
            impSmooth.setTitle("impSmooth");
            impSmooth.getProcessor().smooth();
            //impSmooth.show();
            System.out.println("Smoothing: " + (System.currentTimeMillis() - startTimeImage));

            //Global Threshold with method of choice
            ThresholdHistogram Histogram = new ThresholdHistogram();
            Histogram.exec(impSmooth, globalThresholdMethod);
            int threshold = Histogram.getThreshold();

            //Binary image with global Threshold
            GlobalThreshold GT = new GlobalThreshold();
            impGlobal = GT.exec(impSmooth, threshold);
            measureFGBG = GT.getMeasurements();
            //impGlobal.show();
            System.out.println("GT: " + (System.currentTimeMillis() - startTimeImage));
        } else {
            //Global Threshold with method of choice
            ThresholdHistogram Histogram = new ThresholdHistogram();
            Histogram.exec(impWithoutGradient, globalThresholdMethod);
            int threshold = Histogram.getThreshold();

            //Binary image with global Threshold
            GlobalThreshold GT = new GlobalThreshold();
            impGlobal = GT.exec(impWithoutGradient, threshold);
            measureFGBG = GT.getMeasurements();
            impGlobal.show();
            System.out.println("GT: " + (System.currentTimeMillis() - startTimeImage));
        }

        //Areafilter
        AreaFilter AF = new AreaFilter();
        ImagePlus impGlobalFiltered = AF.exec(impGlobal);
        //impGlobalFiltered.show();
        System.out.println("AreaFilter: " + (System.currentTimeMillis() - startTimeImage));

        ArrayList<Roi> roiListCF;
        if (numberThreshold == 2) {
            //Voronoi 
            Voronoi Vo = new Voronoi();
            ImagePlus impVoronoi = Vo.exec(impGlobalFiltered, blackBackground);
            //impVoronoi.show();
            System.out.println("Voronoi: " + (System.currentTimeMillis() - startTimeImage));

            //Dilation
            Dilation Di = new Dilation();
            ImagePlus impDilated = Di.exec(impGlobalFiltered, impVoronoi, dilations, blackBackground);
            //impDilated.show();
            System.out.println("Dilation: " + (System.currentTimeMillis() - startTimeImage));

            //LocalThreshold
            LocalThreshold LT = new LocalThreshold(localThresholdMethod, imp);
            ArrayList<Roi> roiListLT = LT.exec(impDilated);
            measureFGBG = LT.getMeasurements();
            System.out.println("LT: " + (System.currentTimeMillis() - startTimeImage));
            //TestImpLT
            /*
            //TestImage testImpLT = new TestImage();
            //testImpLT.execRoiList(imp, roiListLT, "testImpLT",Color.CYAN);
            TestImage testImpLTDC = new TestImage();
            testImpLTDC.execRoiListDiffColor(imp, roiListLT, "testImpLTDC");
            //*/
            
            //CompositeFilter       
            CompositeFilter CF = new CompositeFilter();
            roiListCF = CF.exec(imp, roiListLT);
            System.out.println("CF: " + (System.currentTimeMillis() - startTimeImage));
            //TestImpCF
            /*
            //TestImage testImpCF = new TestImage();
            //testImpCF.execRoiList(imp, roiListCF, "TestImpCF",Color.GREEN);
            TestImage testImpCFDC = new TestImage();
            testImpCFDC.execRoiListDiffColor(imp, roiListCF, "testImpCFDC");
            //*/
            
        } else {
            ThresholdToSelection ThresholdToSelectionObject = new ThresholdToSelection();
            impGlobalFiltered.getProcessor().setThreshold(255, 255, ImageProcessor.NO_LUT_UPDATE);
            Roi roiGlobalFiltered = ThresholdToSelectionObject.convert(impGlobalFiltered.getProcessor());
            ShapeRoi roiGlobalFilteredShape = new ShapeRoi(roiGlobalFiltered);
            Roi[] roiArrayGlobalFiltered = roiGlobalFilteredShape.getRois();
            ArrayList<Roi> roiListGlobalFiltered = new ArrayList<Roi>(Arrays.asList(roiArrayGlobalFiltered));

            //CompositeFilter       
            CompositeFilter CF = new CompositeFilter();
            roiListCF = CF.exec(imp, roiListGlobalFiltered);
            System.out.println("CF: " + (System.currentTimeMillis() - startTimeImage));
            //TestImpCF
            /*
            TestImage testImpCFDC = new TestImage();
            testImpCFDC.execRoiListDiffColor(imp, roiListCF, "testImpCFDC");
            //*/
        }
        
        
        //Edge Enhancement
        /*
        EdgeEnhancementHannes EEH = new EdgeEnhancementHannes();
        Roi[] roiArrayEE = EEH.exec(roiListLIF, imp, measureFGBG);
        System.out.println("EdgeEnhancement: " + (System.currentTimeMillis() - startTimeImage));        
        //*/
        
        //*
        EdgeEnhancement EE = new EdgeEnhancement();
        Roi[] roiArrayEE = EE.exec(roiListCF, imp, measureFGBG);
        System.out.println("EdgeEnhancement: " + (System.currentTimeMillis() - startTimeImage));
        //TestImpEE
        //*
        TestImage testImpEEDC = new TestImage();
        testImpEEDC.execRoiArray(imp, roiArrayEE, "testImpEEDC");
        //testImpEEDC.execRoiArrayDiffColor(imp, roiArrayEE, "testImpEEDC");
        //*/
//        Roi[] roiArrayEE=new Roi[roiListLIF.size()];
//        for(int i=0; i<roiListLIF.size();i++){
//            roiArrayEE[i]=roiListLIF.get(i);
//        }
        
        ArrayList<Roi> roiListWS;
        if (watershed == true) {
            //Watershed
            Watershed_Profile WSP = new Watershed_Profile();
            roiListWS = WSP.exec(imp, roiArrayEE, measureFGBG,blackBackground);
            System.out.println("WS: " + (System.currentTimeMillis() - startTimeImage));
            //TestImpWS
            //*
            TestImage testImpWSDC = new TestImage();
            testImpWSDC.execRoiListDiffColor(imp, roiListWS, "testImpWSDC");
            //*/
        } else {
            roiListWS = new ArrayList<Roi>(Arrays.asList(roiArrayEE));
        }
        
        //Remove Roi on edge
        FitSpline FS = new FitSpline();
        ArrayList<Roi> roiListFS = FS.exec(imp,roiListWS);
        System.out.println("FitSpline: " + (System.currentTimeMillis() - startTimeImage));
        //TestImpWS
        /*
        TestImage testImpFSDC = new TestImage();
        testImpFSDC.execRoiListDiffColor(imp, roiListFS, "testImpFSDC");
        //*/

        //Remove Roi on edge
        RemoveRoiEdge RRE = new RemoveRoiEdge();
        ArrayList<Roi> roiListRRE = RRE.exec(imp, roiListFS);
        System.out.println("RemoveRoiOnEdge: " + (System.currentTimeMillis() - startTimeImage));
        //TestImpWS
        /*
        TestImage testImpRREDC = new TestImage();
        testImpRREDC.execRoiListDiffColor(imp, roiListRRE, "testImpRREDC");
        //*/
        
        //Remove Small Roi
        //*
        RemoveSmallRoi RSR = new RemoveSmallRoi();
        ArrayList<Roi> roiListRSR = RSR.exec(imp, roiListRRE);
        System.out.println("RemoveSmallRoi: " + (System.currentTimeMillis() - startTimeImage));
        //*/
        //TestImpWS
        /*
        TestImage testImpRSRDC = new TestImage();
        testImpRSRDC.execRoiListDiffColor(imp, roiListRSR, "testImpRREDC");
        //*/


        //Remove Overlap
        //*
        RemoveOverlap RO = new RemoveOverlap();
        ArrayList<Roi> roiListRO= RO.exec(imp, roiListRSR);
        System.out.println("RemoveOverlap: " + (System.currentTimeMillis() - startTimeImage));
        //*/
        
       
        roiArray = new Roi[roiListRO.size()];
        for(int i=0; i<roiListRO.size();i++){
            ShapeRoi shapeRoi = new ShapeRoi(roiListRO.get(i));
            roiArray[i]=shapeRoi;
        }
       

    }

    public Roi[] getRoiArray() {
        return roiArray;
    }

}
