/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package segmentation;

import java.util.ArrayList;
import ij.gui.Roi;
import ij.ImagePlus;
import java.awt.Rectangle;
import ij.gui.PolygonRoi;
import ij.measure.Measurements;
import ij.measure.ResultsTable;
import ij.plugin.filter.Analyzer;
import java.awt.Polygon;
import java.util.Arrays;

/**
 *
 * @author marliesverschuuren
 */
public class RemoveSmallRoi {

    protected ArrayList<Roi> exec(ImagePlus imp, ArrayList<Roi> roiList) {
        int impWidth = imp.getWidth();
        int impHeight = imp.getHeight();
        ArrayList<Roi> roiListChecked = new ArrayList<Roi>();

        Analyzer.setMeasurements(0);
        int measurements = Measurements.AREA;
        
        ArrayList<Double> areaList = new ArrayList<Double>();
        double sumArea = 0;

        for (int i = 0; i < roiList.size(); i++) {
            //TEST
            //imp.show();
            if(roiList.get(i).getBounds().getWidth()>0 && roiList.get(i).getBounds().getHeight()>0 ){
                imp.setRoi(roiList.get(i));
                ResultsTable rt = new ResultsTable();
                Analyzer analyzer = new Analyzer(imp, measurements, rt);
                analyzer.measure();
                imp.killRoi();
                double area = rt.getValueAsDouble(ResultsTable.AREA, 0);
                if(area>30){
                    roiListChecked.add(roiList.get(i));
                }
            } 
        }

//        for (int i = 0; i < roiList.size(); i++) {
//            Rectangle boundingRect = roiList.get(i).getBounds();
//            imp.setRoi(roiList.get(i));
//            analyzer.measure();
//            imp.killRoi();
//            double area = rt.getValueAsDouble(ResultsTable.AREA, i);
//            areaList.add(area);
//            sumArea = sumArea + area;
//        }
//
//        Double meanArea = sumArea / areaList.size();
//        Double mse = 0.0;
//
//        for (int i = 0; i < areaList.size(); i++) {
//            mse = mse + Math.pow((areaList.get(i) - meanArea), 2);
//        }
//        Double std = Math.sqrt(mse / (areaList.size() - 1));
//        for (int i = 0; i < areaList.size(); i++) {
//
//            //TEST
//            //*
//            imp.show();
//            imp.setRoi(roiList.get(i));
//            imp.killRoi();
//            //*/
//            if(std>meanArea/2){
//                if (areaList.get(i) > meanArea - std) {
//                    roiListCheckedPer.add(roiList.get(i));
//                }
//            }
//            else{ 
//                if(areaList.get(i) > meanArea - 2*std) {
//                    roiListCheckedPer.add(roiList.get(i));
//                }
//            }
//                
//            
//
//        }
        return roiListChecked;
    }
}
