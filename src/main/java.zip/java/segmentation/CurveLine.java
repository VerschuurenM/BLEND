/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package segmentation;

import ij.gui.PolygonRoi;
import ij.gui.Roi;

/**
 *
 * @author Marlies Verschuuren
 */
public class CurveLine {

    protected double[][][] correspondanceArray;

    public CurveLine(double[][][] correspondanceArray) {
        this.correspondanceArray = correspondanceArray;
    }

    protected Roi exec(boolean[][] booleanArray) {
    //Recreate ROI based on booleanArray & correspondanceArray    
        
        float[] xPoints = new float[booleanArray.length];
        float[] yPoints = new float[booleanArray.length];

        //System.out.println(correspondanceArray.length);
        //System.out.println(booleanArray.length);
        for (int i = 0; i < booleanArray.length; i++) {
            for (int j = 0; j < booleanArray[0].length; j++) {
                if (booleanArray[i][j] == true) {
                    xPoints[i] = (float) correspondanceArray[i][j][0];
                    yPoints[i] = (float) correspondanceArray[i][j][1];
                    j = booleanArray[0].length;
                }
            }
        }
        //PolygonRoi(float[] xPoints, float[] yPoints, int nPoints, int type)
        PolygonRoi roi = new PolygonRoi(xPoints, yPoints, booleanArray.length, Roi.POLYGON);

        return roi;
    }
}
