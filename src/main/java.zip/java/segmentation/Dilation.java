/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package segmentation;

import ij.ImagePlus;
import ij.plugin.Duplicator;
import ij.plugin.ImageCalculator;

/**
 *
 * @author Marlies Verschuuren
 */
public class Dilation {

    protected ImagePlus exec(ImagePlus impBinary, ImagePlus impVoronoi, int dilations, boolean blackBackground) {
	//Dilate ROIs in Voronoi-cel

        ImagePlus impDilated = new Duplicator().run(impBinary);
        for (int i = 0; i < dilations; i++) {
            //Dilate
            if(blackBackground==false){
                impDilated.getProcessor().erode();
            }
            else{
                impDilated.getProcessor().erode();
            }
            //Dilation in Voronoi-cell only: AND-operation
            impDilated = new ImageCalculator().run("AND create", impDilated, impVoronoi);

        }
        impDilated.setTitle("impDilated");
        return impDilated;
    }

}
