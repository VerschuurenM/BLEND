/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package segmentation;

import ij.ImagePlus;
import ij.plugin.Duplicator;
import ij.plugin.filter.EDM;

/**
 *
 * @author Marlies Verschuuren
 */
public class Voronoi {

    protected ImagePlus exec(ImagePlus imp, boolean blackBackground) {
    //Creating an Euclidean Distance Map or EDM = greyscale representation of the distance of every pixel to the nearest foreground pixel= belonging to the segmented nuclei. 
    //The points that are saddle points and located in the background of the globally thresholded image, are points that make up the borders of the regions where the ROI of each nucleus can grow in. 
    //These points can be seen as the "ridges". 
        
        //Duplicate imp
        ImagePlus impVoronoi = new Duplicator().run(imp);
        EDM getVoronoi = new EDM();
        //Output = BYTE_OVERWRITE
        EDM.setOutputType(0);
        
        //Depends on settings ImageJ
        if (blackBackground == false) {
            impVoronoi.getProcessor().invert();
        }
        
        //Prepare for processing: String name + imagePlus impVoronoi
        getVoronoi.setup("voronoi", impVoronoi);
        getVoronoi.run(impVoronoi.getProcessor());
        
        //Apply threshold = 0 --> Binary Image
        GlobalThreshold GT = new GlobalThreshold();
        impVoronoi = GT.exec(impVoronoi, 0);

        //Invert impVoronoi 
        impVoronoi.getProcessor().invert();
        impVoronoi.setTitle("impVoronoi");
        return impVoronoi;
    }

}
