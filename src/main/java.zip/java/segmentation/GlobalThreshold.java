/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package segmentation;

import ij.IJ;
import ij.ImagePlus;
import ij.gui.Roi;
import ij.gui.ShapeRoi;
import ij.measure.Measurements;
import ij.plugin.Duplicator;
import ij.measure.ResultsTable;
import ij.plugin.filter.Analyzer;
import ij.plugin.filter.ThresholdToSelection;
import ij.process.ImageProcessor;
import java.util.Hashtable;

/**
 *
 * @author Marlies Verschuuren
 */
public class GlobalThreshold {

    ImagePlus impBinary;
    ImagePlus impOriginal;
    Roi foreground;
    int impWidth;
    int impHeight;

    protected ImagePlus exec(ImagePlus imp, int threshold) {
        impOriginal = new Duplicator().run(imp);
        impWidth = imp.getWidth();
        impHeight = imp.getHeight();

        int[][] impArray = imp.getProcessor().getIntArray();

        for (int i = 0; i < impWidth; i++) {
            for (int j = 0; j < impHeight; j++) {
                if (impArray[i][j] <= threshold) {
                    impArray[i][j] = 0;
                } else {
                    impArray[i][j] = 255;
                }

            }
        }
        impBinary = IJ.createImage("impBinaryGlobalThreshold", "8-bit", impWidth, impHeight, 1);
        impBinary.getProcessor().setIntArray(impArray);
        return impBinary;
    }

    protected double [] getMeasurements() {    
    //Get Measurements Mean & STD_DEV from foreground & background
        
        double[] measure = new double[4];
        
        ThresholdToSelection TTS = new ThresholdToSelection();
        impBinary.getProcessor().setThreshold(255, 255, ImageProcessor.NO_LUT_UPDATE);
        Roi foreground = TTS.convert(impBinary.getProcessor());
        
        Analyzer.setMeasurements(0);
        int measurements = Measurements.MEAN + Measurements.STD_DEV;
        ResultsTable rt = new ResultsTable();
        Analyzer analyzer = new Analyzer(impOriginal, measurements, rt);
        
        //TEST
        //impOriginal.show();
        impOriginal.setRoi(foreground);
        analyzer.measure();
        impOriginal.killRoi();
        
        Roi entireImage = new Roi(0, 0, impWidth, impHeight);
        ShapeRoi background = (new ShapeRoi(entireImage)).not(new ShapeRoi(foreground));
        impOriginal.setRoi(background);
        analyzer.measure();
        impOriginal.killRoi();

        double meanForeGround = rt.getValueAsDouble(ResultsTable.MEAN, 0);
        double stdForeGround = rt.getValueAsDouble(ResultsTable.STD_DEV, 0);
        double meanBackGround = rt.getValueAsDouble(ResultsTable.MEAN, 1);
        double stdBackGround = rt.getValueAsDouble(ResultsTable.STD_DEV, 1);

        measure[0]=meanForeGround;
        measure[1]=stdForeGround;
        measure[2]=meanBackGround;
        measure[3]=stdBackGround;

        return measure;
    }

}
