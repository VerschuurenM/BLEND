/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package segmentation;

import ij.gui.PolygonRoi;
import ij.gui.Roi;
import ij.process.FloatPolygon;
import java.util.ArrayList;
import ij.ImagePlus;
import ij.gui.ShapeRoi;

/**
 *
 * @author marliesverschuuren
 */
public class FitSpline {
//    protected int fitRange;
//
//    public FitSpline(double[][][] correspondanceArray) {
//        this.fitRange = fitRange;
//    }

    protected ArrayList<Roi> exec(ImagePlus imp, ArrayList<Roi> roiList) {
        ArrayList<Roi> roiListFitted = new ArrayList<Roi>(roiList.size());
        for(int i=0; i<roiList.size();i++){
            Roi roi = roiList.get(i);
            FloatPolygon interpolatedRoi = roi.getInterpolatedPolygon(5, false);
            PolygonRoi polygonRoi= new PolygonRoi(interpolatedRoi.xpoints, interpolatedRoi.ypoints, Roi.POLYGON);
            polygonRoi.fitSpline();
            Roi roiFitted = polygonRoi;
            roiListFitted.add(roiFitted);
        }
        return roiListFitted;
    }
}
