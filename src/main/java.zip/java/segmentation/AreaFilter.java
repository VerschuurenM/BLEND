/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package segmentation;

import ij.IJ;
import ij.ImagePlus;
import ij.gui.Roi;
import ij.gui.ShapeRoi;
import ij.plugin.filter.ThresholdToSelection;
import ij.process.ImageProcessor;
import java.awt.Color;

/**
 *
 * @author Marlies Verschuuren
 */
public class AreaFilter {

    protected ImagePlus exec(ImagePlus imp) {
        //Remove small ROIs < 5% maxPerimeter

        ThresholdToSelection ThresholdToSelectionObject = new ThresholdToSelection();
        ImagePlus impAreaFilter = IJ.createImage("impAreaFilter", "8-bit black", imp.getWidth(), imp.getHeight(), 1);
        imp.getProcessor().setThreshold(255, 255, ImageProcessor.NO_LUT_UPDATE);

        // Roi: all foregrond pixels
        Roi roiGlobal = ThresholdToSelectionObject.convert(imp.getProcessor());

        //Convert ShapeRoi into RoiArray (Seperate Rois)
        ShapeRoi roiGlobalShape = new ShapeRoi(roiGlobal);
        Roi[] roiArray = roiGlobalShape.getRois();

        //maxLength is maximum perimeter of Roi
        double maxLength = 0;
        for (int i = 0; i < roiArray.length; i++) {
            if (roiArray[i].getLength() > maxLength) {
                maxLength = roiArray[i].getLength();
            }
        }

        //Set White Color
        Color white = new Color(255, 255, 255);
        impAreaFilter.getProcessor().setColor(white);

        //Set threshold for perimeter at 5% of maxLength --> fill Roi in impAreaFilter
        for (int i = 0; i < roiArray.length; i++) {
            if (roiArray[i].getLength() > maxLength / 100 * 5) {
                impAreaFilter.getProcessor().fill(roiArray[i]);
            }
        }
        return impAreaFilter;
    }
}
