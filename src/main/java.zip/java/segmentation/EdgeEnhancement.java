    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package segmentation;

import ij.gui.PolygonRoi;
import ij.gui.Roi;
import ij.gui.ShapeRoi;
import ij.process.FloatPolygon;
import java.util.ArrayList;
import ij.ImagePlus;
import ij.process.FloatProcessor;
import ij.process.ImageProcessor;
import ij.ImagePlus;
import ij.plugin.Duplicator;
import java.awt.Color;
import ij.gui.Overlay;
import ij.measure.Measurements;
import ij.measure.ResultsTable;
import ij.plugin.ImageCalculator;
import ij.plugin.filter.Analyzer;
import ij.plugin.filter.GaussianBlur;
import ij.plugin.filter.RankFilters;
import java.awt.Polygon;

/**
 *
 * @author Marlies Verschuuren
 */
public class EdgeEnhancement {

    protected float maxPathStrenght;
    protected float pathStrenght;
    protected double[][][] correspondanceArray;
    Roi[] roiArray;
    boolean stopIteration = false;
    boolean splitRoi = true;
    int indexLoop1;
    int indexLoop2;

    protected Roi[] exec(ArrayList<Roi> roiListBeforeDP, ImagePlus imp, double[] measureFGBGlt) {
    
    //Iterative search to optimal path describing the edge of each nucleus
    //For loop over all ROIs 
        //Iterative (#=it) search for path with maximal pathStrength
            //Create interpolated ROI: shuffle ROI --> Different starting point 
            //Check loops in ROI
                //LengthLoop1 > 0.10 * totalLength && LengthLoop2 > 0.10 * totalLength --> splitROI
                    //If mean splitROI > MEAN - STDEV (foreground measurement local threshold) --> add extra ROI to RoiList
                //Else --> cutLoop
            //Straighten edge: width = rangeEdge
            //Dynamic programming --> Search optimal path in Straightened edge --> BooleanArray
            //CurveLine: reconstruct optimal Path
        //Add finalRoi to roiListFinal
        
        ArrayList<Roi> roiListFinal = new ArrayList<Roi>();
        int originalNumber = roiListBeforeDP.size();
        for (int i = 0; i < roiListBeforeDP.size(); i++) {
            Roi localRoi = roiListBeforeDP.get(i);
            double rangeEdge = 10.0;
            double interpolationDist = rangeEdge / 2;
            maxPathStrenght = 0;
            int it = 0;
            boolean multipleRoi=false;
            if (localRoi.getBounds().getWidth() * localRoi.getBounds().getHeight() > 2 * rangeEdge) {

                //TEST
                /*
                 ImagePlus impTest = new Duplicator().run(imp);
                 impTest.setTitle("iterationTest");
                 Overlay overlayTest = new Overlay();
                 impTest.show();
                 //*/
                /*
                 ImagePlus impResult = new Duplicator().run(imp);
                 impResult.setTitle("finalResult");
                 Overlay result = new Overlay();
                 localRoi.setStrokeColor(Color.blue);
                 result.add(localRoi);
                 impResult.setOverlay(result);
                 impResult.show();
                 System.out.println("");
                 //*/
                 
                do {
                    it += 1;
                    splitRoi = false;
                    if (localRoi.getBounds().getWidth() * localRoi.getBounds().getHeight() > 2 * rangeEdge) {
                        //FloatPolygon, an interpolated version of this selection that has points spaced 10/2 pixel apart + smoothed
                        FloatPolygon interpolatedRoi = localRoi.getInterpolatedPolygon(interpolationDist, true);
                        FloatPolygon interpolatedRoiShuffle = shuffle(it, interpolatedRoi);

                        if (interpolatedRoi.getBounds().getWidth() * interpolatedRoi.getBounds().getHeight() > 5.0) {
                            PolygonRoi initiationRoi = null;
                            //initiationRoi= new PolygonRoi(interpolatedRoi,Roi.POLYGON);
                            //initiationRoi= new PolygonRoi(interpolatedRoiShuffle,Roi.POLYGON);
                            initiationRoi = new PolygonRoi(eliminateLoop(interpolatedRoiShuffle), Roi.POLYGON);
                            
                            //*
                            if (splitRoi == true) {
                                multipleRoi=true;
                                ArrayList<PolygonRoi> temporal = splitRoi(interpolatedRoiShuffle);
                                
                                initiationRoi = temporal.get(0);
                                maxPathStrenght = 0;
                                it = 0;

                                Analyzer.setMeasurements(0);
                                int measurements = Measurements.MEAN;
                                Analyzer.setMeasurements(measurements);

                                ResultsTable rtRoi = new ResultsTable();
                                Analyzer analyzerRoi = new Analyzer(imp, measurements, rtRoi);

                                //imp.show();
                                imp.setRoi(temporal.get(1));
                                analyzerRoi.measure();
                                imp.killRoi();
                                double meanRoi = rtRoi.getValueAsDouble(ResultsTable.MEAN, 0);

                                if (meanRoi > (measureFGBGlt[0]-measureFGBGlt[1])
                                        && temporal.get(1).getBounds().getWidth() > rangeEdge
                                        && temporal.get(1).getBounds().getHeight() > rangeEdge) {
                                    roiListBeforeDP.add(temporal.get(1));
                                } else {

                                }
                            }
                            //*/
                            
                            if (initiationRoi.getBounds().getWidth() > 0 && initiationRoi.getBounds().getHeight() > 0) {
                                StraightenLine SL = new StraightenLine();
                                float[][] edgeArray = SL.exec(imp, initiationRoi, (int) rangeEdge);
                                correspondanceArray = SL.getCorrespondanceArray();
                                
                                DynamicProgramming DP = new DynamicProgramming();
                                boolean[][] booleanArray = DP.exec(edgeArray, false);
                                pathStrenght = DP.getPathStrenght();

                                
                                
                                CurveLine CL = new CurveLine(correspondanceArray);
                                localRoi = CL.exec(booleanArray);
                            } else {
                                System.out.println("BREAK; polygonRoi");
                                break;
                            }

                            //TEST
                            /*
                             getColor clr = new getColor();
                             Color color = clr.exec(it);
                             localRoi.setStrokeColor(color);
                             overlayTest.add(localRoi);
                             impTest.setOverlay(overlayTest);
                             //*/
                            
                            //System.out.println("Number iterations= " + it + " pathstrenght= " + pathStrenght);
                            if ((maxPathStrenght <= pathStrenght)) {
                                //System.out.println(it + "' Path better");
                                roiListBeforeDP.set(i, localRoi);
                                maxPathStrenght = pathStrenght;
                            }
                        }
                    }
                } while (it < 25);
                //Test
                /*
                 roiListBeforeDP.get(i).setStrokeColor(Color.red);
                 result.add(roiListBeforeDP.get(i));
                 impResult.setOverlay(result);
                 impResult.show();
                 //*/
            }
            //ShapeRoi convertShapeRoi = new ShapeRoi(roiListBeforeDP.get(i));
            Roi roiDP = roiListBeforeDP.get(i);
            if(multipleRoi==true || i >= originalNumber){
                //convertShapeRoi.setStrokeColor(Color.CYAN);
                roiDP.setStrokeColor(Color.CYAN);
            }
            //roiListFinal.add(convertShapeRoi);
            roiListFinal.add(roiDP);
        }
        roiArray = new Roi[roiListFinal.size()];
        roiListFinal.toArray(roiArray);
        return roiArray;
    }

    protected Roi execRoi(Roi roiBefore, ImagePlus imp,double[] measureFGBGlt) {
    //see Exec; 1 ROI
        
        //TEST
        /*
         ImagePlus impTest = new Duplicator().run(imp);
         impTest.setTitle("iterationTest");
         Overlay overlayTest = new Overlay();
         impTest.show();
         //*/
        /*
         ImagePlus impResult = new Duplicator().run(imp);
         impResult.setTitle("finalResult");
         Overlay result = new Overlay();
         roiBefore.setStrokeColor(Color.blue);
         result.add(roiBefore);
         impResult.setOverlay(result);
         impResult.show();
         //*/

//        ShapeRoi roiCombinedShape = new ShapeRoi(roiBefore);
//
//        Roi[] roiArrayLocal = roiCombinedShape.getRois();
//        
//
//        ArrayList<Roi> roiListLocal = new ArrayList<Roi>();
//        for (int j = 0; j < roiArrayLocal.length; j++) {
//            //imp.setRoi(roiArrayLocal[j]);
//            if (roiArrayLocal[j].getBounds().getWidth() * roiArrayLocal[j].getBounds().getHeight() > 2 * rangeEdge) {
//                roiListLocal.add(roiArrayLocal[j]);
//            }
//        }
//        for (int j = 0; j < roiListLocal.size(); j++) {

            Roi roiAfter = roiBefore;
            int rangeEdge = 10;
            double interpolationDist = rangeEdge / 2;
            maxPathStrenght = 0;
            int it = 0;

            //25 iterations  
            stopIteration = false;
            do {
                it += 1;
                splitRoi = false;
                if (roiBefore.getBounds().getWidth() * roiBefore.getBounds().getHeight() > 2 * rangeEdge) {
                    //FloatPolygon, an interpolated version of this selection that has points spaced 10/2 pixel apart + smoothed
                    FloatPolygon interpolatedRoi = roiBefore.getInterpolatedPolygon(interpolationDist, true);
                    FloatPolygon interpolatedRoiShuffle = shuffle(it, interpolatedRoi);

                    if (interpolatedRoi.getBounds().getWidth() * interpolatedRoi.getBounds().getHeight() > 5.0) {
                        PolygonRoi initiationRoi = null;
                        /*
                        initiationRoi= new PolygonRoi(interpolatedRoi, Roi.POLYGON);
                        imp.show();
                        imp.setRoi(roiBefore);
                        imp.setRoi(initiationRoi);
                        //*/
                        //*
                        initiationRoi = new PolygonRoi(eliminateLoop(interpolatedRoiShuffle), Roi.POLYGON);
                        
//                        if (splitRoi == true) {
//                            ArrayList<PolygonRoi> temporal = splitRoi(interpolatedRoiShuffle);
//                            initiationRoi = temporal.get(0);
//                            maxPathStrenght = 0;
//                            it = 0;
//                            
//                            Analyzer.setMeasurements(0);
//                                int measurements = Measurements.MEAN;
//                                Analyzer.setMeasurements(measurements);
//
//                                ResultsTable rtRoi = new ResultsTable();
//                                Analyzer analyzerRoi = new Analyzer(imp, measurements, rtRoi);
//
//                                //imp.show();
//                                imp.setRoi(temporal.get(1));
//                                analyzerRoi.measure();
//                                imp.killRoi();
//                                double meanRoi = rtRoi.getValueAsDouble(ResultsTable.MEAN, 0);
//
//                                if (meanRoi > (measureFGBGlt[0])
//                                        && temporal.get(1).getBounds().getWidth() > rangeEdge
//                                        && temporal.get(1).getBounds().getHeight() > rangeEdge) {
//                                    roiListLocal.add(temporal.get(1));
//                                } else {
//
//                                }
//                            }
                            //*/
                        


                        if (initiationRoi.getBounds().getWidth() > 0 && initiationRoi.getBounds().getHeight() > 0) {
                            StraightenLine SL = new StraightenLine();
                            float[][] edgeArray = SL.exec(imp, initiationRoi, (int) rangeEdge);
                            correspondanceArray = SL.getCorrespondanceArray();
                            
                            DynamicProgramming DP = new DynamicProgramming();
                            boolean[][] booleanArray = DP.exec(edgeArray, false);
                            pathStrenght = DP.getPathStrenght();
                            
                            CurveLine CL = new CurveLine(correspondanceArray);
                            roiBefore=CL.exec(booleanArray);
                            //localRoi = CL.exec(booleanArray);
                        } else {
                            System.out.println("BREAK; polygonRoi");
                            //TEST
                            /*
                             impTest.show();
                             impTest.setRoi(initiationRoi);
                             impTest.killRoi();
                             //*/
                            break;
                        }

                        //TEST
                        /*
                         getColor clr = new getColor();
                         Color color = clr.exec(it);
                         localRoi.setStrokeColor(color);
                         overlayTest.add(localRoi);
                         impTest.setOverlay(overlayTest);
                         //*/
                        //System.out.println("Number iterations= " + it + " pathstrenght= " + pathStrenght);
                        if ((maxPathStrenght <= pathStrenght)) {
                            //System.out.println(it + "' Path better");
                            roiAfter = roiBefore;
                            //roiListLocal.set(j, localRoi);
                            maxPathStrenght = pathStrenght;

                        }
                    }
                }
            } while (it < 25);
        //}
//        roiCombinedShape = new ShapeRoi(roiListLocal.get(0));
//        for (int j = 1; j < roiListLocal.size(); j++) {
//            ShapeRoi convertShapeRoi = new ShapeRoi(roiListLocal.get(j));
//            roiCombinedShape.or(convertShapeRoi);
//        }
        //Test
        /*
         roiCombinedShape.setStrokeColor(Color.red);
         result.add(roiCombinedShape);
         impResult.setOverlay(result);
         impResult.show();
         //*/
        //return roiCombinedShape;
        return roiAfter;

    }

    protected FloatPolygon eliminateLoop(FloatPolygon polygonBefore) {

        FloatPolygon polygonReturn = polygonBefore;

        float[] xCoord = polygonBefore.xpoints;
        float[] yCoord = polygonBefore.ypoints;

        for (indexLoop1 = 0; indexLoop1 < xCoord.length - 1; indexLoop1++) {
            float x1 = xCoord[indexLoop1];
            float y1 = yCoord[indexLoop1];
            float x2 = xCoord[indexLoop1 + 1];
            float y2 = yCoord[indexLoop1 + 1];
            boolean intersect = false;
            for (indexLoop2 = indexLoop1 + 2; indexLoop2 < xCoord.length - 1; indexLoop2++) {
                float x3 = xCoord[indexLoop2];
                float y3 = yCoord[indexLoop2];
                float x4 = xCoord[indexLoop2 + 1];
                float y4 = yCoord[indexLoop2 + 1];

                //Check if segments are vertical
                if (x1 == x2 && x3 == x4) {
                    //Check if segments are located on the same line
                    if (x1 == x3) {
                        //Check if segments overlap
                        if (Math.min(y1, y2) < Math.max(y3, y4) && Math.min(y3, y4) < Math.max(y1, y2)) {
                            intersect = true;
                            polygonReturn = cutLoop(polygonBefore);
                            break;
                        }
                    }
                } 
                else if (x1 == x2 && x3 != x4) {
                    float a2 = (y4 - y3) / (x4 - x3);
                    float b2 = y3 - a2 * x3;
                    float yi = a2 * x1 + b2;
                    if (yi > Math.min(y1, y2) && yi < Math.max(y1, y2)) {
                        if (yi > Math.min(y3, y4) && yi < Math.max(y3, y4)) {
                            intersect = true;
                            polygonReturn = cutLoop(polygonBefore);
                            break;
                        }
                    }
                } else if (x1 != x2 && x3 == x4) {
                    float a1 = (y2 - y1) / (x2 - x1);
                    float b1 = y1 - a1 * x1;
                    float yi = a1 * x3 + b1;
                    if (yi > Math.min(y1, y2) && yi < Math.max(y1, y2)) {
                        if (yi > Math.min(y3, y4) && yi < Math.max(y3, y4)) {
                            intersect = true;
                            polygonReturn = cutLoop(polygonBefore);
                            break;
                        }
                    }
                } else {
                    float a1 = (y2 - y1) / (x2 - x1);
                    float b1 = y1 - a1 * x1;
                    float a2 = (y4 - y3) / (x4 - x3);
                    float b2 = y3 - a2 * x3;

                    if (a1 == a2 && b1 == b2) {
                        if (Math.min(x1, x2) < Math.max(x3, x4) && Math.min(x3, x4) < Math.max(x1, x2)) {
                            intersect = true;
                            polygonReturn = cutLoop(polygonBefore);
                            break;
                        }
                    } else {
                        float xi = -(b1 - b2) / (a1 - a2);

                        if (xi > Math.min(x1, x2) && xi < Math.max(x1, x2)) {
                            if (xi > Math.min(x3, x4) && xi < Math.max(x3, x4)) {
                                intersect = true;
                                polygonReturn = cutLoop(polygonBefore);
                                break;
                            }
                        }

                    }
                }
            }
            if (intersect == true) {
                break;
            }
        }
        return polygonReturn;
    }

    protected FloatPolygon cutLoop(FloatPolygon polygonRoi) {
        float[] xCoord = polygonRoi.xpoints;
        float[] yCoord = polygonRoi.ypoints;

        ArrayList<Float> xCoordList = new ArrayList<Float>();
        for (int i = 0; i < xCoord.length; i++) {
            xCoordList.add(xCoord[i]);
        }
        ArrayList<Float> yCoordList = new ArrayList<Float>();
        for (int i = 0; i < yCoord.length; i++) {
            yCoordList.add(yCoord[i]);
        }

        int lengthLoop1 = indexLoop2 - indexLoop1;
        int lengthLoop2 = (xCoord.length - 1 - indexLoop2) + (indexLoop1);
        if (lengthLoop1 > 0.10 * xCoord.length && lengthLoop2 > 0.10 * xCoord.length) {
            //stopIteration=true;
            splitRoi = true;
        } else if (lengthLoop1 < lengthLoop2) {
            int count = 0;
            while (count < (indexLoop2 - indexLoop1)) {
                xCoordList.remove(indexLoop1 + 1);
                yCoordList.remove(indexLoop1 + 1);
                count++;
            }
        } else {
            for (int i = indexLoop2; i < xCoord.length; i++) {
                xCoordList.remove(indexLoop2);
                yCoordList.remove(indexLoop2);
            }
            for (int i = 0; i <= indexLoop1; i++) {
                xCoordList.remove(0);
                yCoordList.remove(0);
            }
        }
        float[] xCoordReturn = new float[xCoordList.size()];
        for (int i = 0; i < xCoordList.size(); i++) {
            xCoordReturn[i] = xCoordList.get(i);
        }
        float[] yCoordReturn = new float[yCoordList.size()];
        for (int i = 0; i < yCoordList.size(); i++) {
            yCoordReturn[i] = yCoordList.get(i);
        }
        return new FloatPolygon(xCoordReturn, yCoordReturn);
    }

    protected ArrayList<PolygonRoi> splitRoi(FloatPolygon polygonRoi) {
        ArrayList<PolygonRoi> temporal = new ArrayList<PolygonRoi>();

        float[] xCoord = polygonRoi.xpoints;
        float[] yCoord = polygonRoi.ypoints;

        float[] xCoord1 = new float[(indexLoop1 + 1) + (xCoord.length - indexLoop2)];
        float[] yCoord1 = new float[xCoord1.length];

        float[] xCoord2 = new float[indexLoop2 - indexLoop1];
        float[] yCoord2 = new float[xCoord2.length];

        int count1 = 0;
        int count2 = 0;
        for (int i = 0; i <= indexLoop1; i++) {
            xCoord1[count1] = xCoord[i];
            yCoord1[count1] = yCoord[i];
            count1++;
        }
        for (int i = indexLoop2; i < xCoord.length; i++) {
            xCoord1[count1] = xCoord[i];
            yCoord1[count1] = yCoord[i];
            count1++;
        }
        for (int i = indexLoop1 + 1; i <= indexLoop2; i++) {
            xCoord2[count2] = xCoord[i];
            yCoord2[count2] = yCoord[i];
            count2++;
        }
        PolygonRoi roi1 = new PolygonRoi(xCoord1, yCoord1, Roi.POLYGON);
        PolygonRoi roi2 = new PolygonRoi(xCoord2, yCoord2, Roi.POLYGON);

        temporal.add(roi1);
        temporal.add(roi2);

        return temporal;

    }

    protected FloatPolygon shuffle(int it, FloatPolygon polygonBefore) {
        float[] xCoord = polygonBefore.xpoints;
        float[] yCoord = polygonBefore.ypoints;
        ArrayList<Float> xCoordList = new ArrayList<Float>();
        ArrayList<Float> yCoordList = new ArrayList<Float>();
        for (int index = 0; index < xCoord.length; index++) {
            if (xCoord[index] > 0 || yCoord[index] > 0) {
                xCoordList.add(xCoord[index]);
                yCoordList.add(yCoord[index]);
            }
        }

        int start = 0;
        if (it % 5 == 0) {
            start = 0;
        } else if (it % 5 == 1) {
            start = xCoordList.size() / 5;
        } else if (it % 5 == 2) {
            start = xCoordList.size() / 5 * 2;
        } else if (it % 5 == 3) {
            start = xCoordList.size() / 5 * 3;
        } else if (it % 5 == 4) {
            start = xCoordList.size() / 5 * 4;
        }
        //*/
        float[] xCoordSwap = new float[xCoordList.size()];
        float[] yCoordSwap = new float[yCoordList.size()];

        for (int i = 0; i < xCoordList.size(); i++) {
            if ((start + i) < xCoordList.size()) {
                xCoordSwap[i] = xCoordList.get(start + i);
                yCoordSwap[i] = yCoordList.get(start + i);
            } else {
                xCoordSwap[i] = xCoordList.get(start + i - (xCoordList.size() - 1));
                yCoordSwap[i] = yCoordList.get(start + i - (yCoordList.size() - 1));
            }

        }
        FloatPolygon polygonReturn = new FloatPolygon(xCoordSwap, yCoordSwap);
        return polygonReturn;
    }

    protected void createImage(float[][] edgeArray, String title) {
        ImageProcessor ip = new FloatProcessor(edgeArray.length, edgeArray[0].length);
        ImagePlus imp = new ImagePlus(title, ip);
        imp.getProcessor().setFloatArray(edgeArray);
        imp.show();
    }
}
