package shapeDescriptors;


import java.awt.Polygon;
import java.util.ArrayList;
import java.util.List;

import ij.ImagePlus;
import ij.gui.Roi;
import ij.plugin.frame.RoiManager;


public class Curvature {
	double[] curvatureDescriptors;
	
	public void exec(ImagePlus imp, Roi roi, int range){
		curvatureDescriptors = new double[3];
		
                // Get the coordinates from a roi and use linear interpolation to fill the gaps
		int[][] contourArray = GetROICoordinates(roi);
                // [0] bending energy/mean square curvature of outline || [1] tilt (# of sign switches) || [2] angle (# of angle switches)
		double[] returnMatrix = Curvatures(contourArray, range);		
		curvatureDescriptors[0] = returnMatrix[0];
		curvatureDescriptors[1] = returnMatrix[1];
		curvatureDescriptors[2] = returnMatrix[2];
			
        }
	
	public double[] getCurvatureDescriptors() {
		return curvatureDescriptors;
	}
	private double[] Curvatures(int[][] contourArray, int range) {
		int contourArrayLength = contourArray[1].length;
		double[] curvature = new double[contourArrayLength];
		double curvatureSum = 0;
		int angle = 0;
		int tilt = 0;
		for( int i = 0 ; i < contourArrayLength ; i++){

			double dx1 = 0;
			double dy1 = 0;
			double dx2 = 0;
			double dy2 = 0;
			double cx;
			double cy;
			if( i >= range && i < contourArrayLength - range ){
				
				dx1 = contourArray[0][i-range]-contourArray[0][i];
				dy1 = contourArray[1][i]-contourArray[1][i-range];
				
				dx2 = contourArray[0][i+range]-contourArray[0][i];
				dy2 = contourArray[1][i]-contourArray[1][i+range];
				
				cx = Math.floor((contourArray[0][i-range]+contourArray[0][i]+contourArray[0][i+range])/3);
				cy = Math.floor((contourArray[1][i-range]+contourArray[1][i]+contourArray[1][i+range])/3);
			}
			else if( i < range){
				
				dx1 = contourArray[0][contourArrayLength+i-range]-contourArray[0][i];
				dy1 = contourArray[1][i]-contourArray[1][contourArrayLength+i-range];

				dx2 = contourArray[0][i+range]-contourArray[0][i];
				dy2 = contourArray[1][i]-contourArray[1][i+range];

				cx = Math.floor((contourArray[0][contourArrayLength+i-range]+contourArray[0][i]+contourArray[0][i+range])/3);
				cy = Math.floor((contourArray[1][i]+contourArray[1][contourArrayLength+i-range]+contourArray[1][i+range])/3);
			}	
			else if( i >= contourArrayLength - range){

				dx1 = contourArray[0][i-range]-contourArray[0][i];
				dy1 = contourArray[1][i]-contourArray[1][i-range];

				dx2 = contourArray[0][i+range-contourArrayLength]-contourArray[0][i];
				dy2 = contourArray[1][i]-contourArray[1][i+range-contourArrayLength];

				cx = Math.floor((contourArray[0][i-range]+contourArray[0][i]+contourArray[0][i+range-contourArrayLength])/3);
				cy = Math.floor((contourArray[1][i-range]+contourArray[1][i]+contourArray[1][i+range-contourArrayLength])/3);

			}	

				

			double angle1 = Math.atan2(dy1,dx1);
			double angle2 = Math.atan2(dy2,dx2);
			
			curvature[i]=Math.abs(angle2-angle1);
			
			/*for ( int j = 0 ; j < contourArrayLength ; j++){
				if(contourArray[0][j] == cx && contourArray[1][j] == cy && Math.abs(curvature[i])>Math.PI){
					curvature[i]=2*Math.PI-Math.abs(curvature[i]);
				}

				else if(contourArray[0][j] != cx || contourArray[1][j] != cy  && Math.abs(curvature[i])<Math.PI){
					curvature[i]=2*Math.PI-Math.abs(curvature[i]);
				}
			}
			curvature[i]=Math.PI-Math.abs(curvature[i]);*/
			if(curvature[i] == curvature[i]){
				curvatureSum = curvatureSum + curvature[i];;
			}

			
			if(dx1 != dx2 || dy1 != dy2){
				angle++;
			}
			if(dx1 < dx2 || dy1 < dy2){
				tilt++;
			}
			

		}	
		double[] returnMatrix = new double[3];
		
		returnMatrix[0] = curvatureSum/contourArrayLength;
		returnMatrix[1] = (double)tilt/contourArrayLength;
		returnMatrix[2] = (double)angle/contourArrayLength;
		return returnMatrix;
		
	}
	private int[][] GetROICoordinates(Roi roi) {
		
		Polygon p = roi.getPolygon(); 
		
		ArrayList<Integer> ROICoordinatesX = new ArrayList<Integer>();
		ArrayList<Integer> ROICoordinatesY = new ArrayList<Integer>();
		
		for( int i = 0 ; i < p.npoints-1 ; i++){
			
                        // Small step between coordinates --> Add Coordinate
			if (Math.abs(p.xpoints[i] - p.xpoints[i+1]) < 2 && Math.abs(p.ypoints[i] - p.ypoints[i+1]) < 2){

				ROICoordinatesX.add(p.xpoints[i]);
				ROICoordinatesY.add(p.ypoints[i]);
			
			}
                        
                        // Big step between coordinates --> Add Coordinate  + Interpolate      
			else if (Math.abs(p.xpoints[i] - p.xpoints[i+1]) >= 2 || Math.abs(p.ypoints[i] - p.ypoints[i+1]) >= 2){
			
				ROICoordinatesX.add(p.xpoints[i]);
				ROICoordinatesY.add(p.ypoints[i]);
				
				int pointAddsX = -(p.xpoints[i] - p.xpoints[i+1]);
				int pointAddsY = -(p.ypoints[i] - p.ypoints[i+1]);
                                
                                // dx >= dy --> 
				if (Math.abs(p.xpoints[i] - p.xpoints[i+1]) >= Math.abs(p.ypoints[i] - p.ypoints[i+1])){

					for( int j = 1 ; j < Math.abs(pointAddsX) ; j++){
						ROICoordinatesX.add(p.xpoints[i] + j * (pointAddsX/Math.abs(pointAddsX)));
						ROICoordinatesY.add(p.ypoints[i] + Math.round(j * (float)pointAddsY/pointAddsX));
					}
				}
                                //dy > dx -->
				else{
					for( int j = 1 ; j < Math.abs(pointAddsY) ; j++){
						ROICoordinatesY.add(p.ypoints[i] + j * (pointAddsY/Math.abs(pointAddsY)));
						ROICoordinatesX.add(p.xpoints[i] + Math.round(j * (float)pointAddsX/pointAddsY));
					}
				}
				
			}
		}
		
		int[][] contourArray = new int[2][ROICoordinatesX.size()];
		for ( int i = 0 ; i < ROICoordinatesX.size() ; i++){
			contourArray[0][i] = ROICoordinatesX.get(i);
			contourArray[1][i] = ROICoordinatesY.get(i);
			
		}
		return contourArray;
	}
}


	