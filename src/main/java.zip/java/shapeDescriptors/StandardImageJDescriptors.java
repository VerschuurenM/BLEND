package shapeDescriptors;
import ij.ImagePlus;
import ij.gui.Roi;
import ij.measure.ResultsTable;
import ij.plugin.filter.Analyzer;
import ij.plugin.frame.RoiManager;
import ij.measure.*;


public class StandardImageJDescriptors {
	

	
	private double[] standardDescriptors;

	private int measurements;
	private Analyzer analyzer;
	
	public StandardImageJDescriptors(){
		
		measurements = Analyzer.getMeasurements();
		Analyzer.setMeasurements(0);
		measurements = Measurements.AREA + Measurements.PERIMETER + Measurements.ELLIPSE + Measurements.SHAPE_DESCRIPTORS + Measurements.FERET;
		Analyzer.setMeasurements(measurements);
		
		standardDescriptors = new double[12];
	}
	
	
	public void exec(ImagePlus imp, Roi roi){
		
		imp.setRoi(roi);

		ResultsTable rt = new ResultsTable();
		analyzer = new Analyzer(imp, measurements, rt); 
		analyzer.measure();
			
			
			
		standardDescriptors[0] = rt.getValueAsDouble(ResultsTable.AREA, 0);
		
		standardDescriptors[1] = rt.getValueAsDouble(ResultsTable.PERIMETER, 0);
		
		standardDescriptors[2] = rt.getValueAsDouble(ResultsTable.MAJOR, 0);
		standardDescriptors[3] = rt.getValueAsDouble(ResultsTable.MINOR, 0);
		standardDescriptors[4] = rt.getValueAsDouble(ResultsTable.ANGLE, 0);
		
		standardDescriptors[5] = rt.getValueAsDouble(ResultsTable.FERET, 0);
		standardDescriptors[6] = rt.getValueAsDouble(ResultsTable.MIN_FERET, 0);
		standardDescriptors[7] = rt.getValueAsDouble(ResultsTable.FERET_ANGLE, 0);
		
		standardDescriptors[8] = rt.getValueAsDouble(ResultsTable.CIRCULARITY, 0);
		standardDescriptors[9] = rt.getValueAsDouble(ResultsTable.ASPECT_RATIO, 0);		//eccentricity
		standardDescriptors[10] = rt.getValueAsDouble(ResultsTable.ROUNDNESS, 0);
		standardDescriptors[11] = rt.getValueAsDouble(ResultsTable.SOLIDITY, 0);
		
		

	}
				


	public double[] getStandardDescriptors() {
		return standardDescriptors;
	}
}
