package shapeDescriptors;
import ij.ImagePlus;
import ij.gui.Roi;
import ij.measure.Calibration;
import ij.plugin.frame.RoiManager;
import ij.process.ByteProcessor;
import ij.process.FloatProcessor;
import ij.process.ImageProcessor;
import ij.process.ShortProcessor;

import java.awt.Rectangle;
import java.util.List;


public class HuInvariantMoments {
	
	Calibration cal;
	double[] centroid;
	double[] invariantMoments;
	
	public void exec(ImagePlus imp, Roi roi) {
		 
					
		ImageProcessor ip = imp.getProcessor();

		cal = imp.getCalibration();
		float[] ctable = cal.getCTable();
		
		Rectangle rect = roi.getBounds();
		ImageProcessor ip2 = this.getMask(ip, rect);
		int width = ip2.getWidth();
	
		float[] pixels;
		if (ctable!=null) {
			pixels = CalibratePixels(ip2.getPixels(), ctable);
		}
		else {
			pixels = this.toFloatPixels(ip2.getPixels());
		}
			
		double[][] binCoefs = MomentStatistics(rect);
		double[][] rawMoments = CalculateRawMoments(pixels, width);
		double[][] centralMoments = CalculateCentralMoments(pixels, width, rawMoments, binCoefs);
		double[][] scaledMoments = calculateScaledMoments(pixels, width, centralMoments);
                
                invariantMoments = new double[7];
                invariantMoments[0]=scaledMoments[2][0] + scaledMoments[0][2];
                invariantMoments[1]=Math.pow((scaledMoments[2][0] - scaledMoments[0][2]),2)+ 4*Math.pow(scaledMoments[1][1],2);
                invariantMoments[2]=Math.pow((scaledMoments[3][0] - (3*scaledMoments[1][2])),2)+ Math.pow(((3*scaledMoments[2][1]) - (scaledMoments[0][3])),2);
                invariantMoments[3]=Math.pow((scaledMoments[3][0] + scaledMoments[1][2]),2)+ Math.pow((scaledMoments[2][1] + scaledMoments[0][3]),2);
                invariantMoments[4]=(scaledMoments[3][0] - (3*scaledMoments[1][2]))*(scaledMoments[3][0] - scaledMoments[1][2])*((Math.pow((scaledMoments[3][0] + scaledMoments[1][2]),2))-3*(Math.pow((scaledMoments[2][1] + scaledMoments[0][3]),2)))
                      + (3*scaledMoments[2][1]-scaledMoments[0][3])*(scaledMoments[2][1] + scaledMoments[0][3])*(3*(Math.pow((scaledMoments[3][0] + scaledMoments[1][2]),2))-(Math.pow((scaledMoments[2][1] + scaledMoments[0][3]),2)));
		invariantMoments[5]=(scaledMoments[2][0] - scaledMoments[0][2])*(Math.pow((scaledMoments[3][0] + scaledMoments[1][2]),2)-Math.pow((scaledMoments[2][1] + scaledMoments[0][3]),2)+(4*scaledMoments[1][1]*(scaledMoments[3][0] + scaledMoments[1][2])*(scaledMoments[2][1] + scaledMoments[0][3])));
                invariantMoments[6]=((3*scaledMoments[2][1]) - (scaledMoments[0][3]))*(scaledMoments[3][0] + scaledMoments[1][2])
                        *((Math.pow((scaledMoments[3][0] + scaledMoments[1][2]),2))-3*(Math.pow((scaledMoments[2][1] + scaledMoments[0][3]),2)))
                        +(scaledMoments[3][0] - (3*scaledMoments[1][2]))*(scaledMoments[2][1] +scaledMoments[0][3])
                        *(3*(Math.pow((scaledMoments[3][0] + scaledMoments[1][2]),2))-Math.pow((scaledMoments[2][1] + scaledMoments[0][3]),2));
		


		
	}
	
	private double[][] MomentStatistics (Rectangle rect ){
                int order=4;
		double[][] carray = new double[order][];

		for (int i = 1 ; i <= order ; i++){
			
			carray[i-1] = new double [i];
			for (int j = 1; j <= i; j++) {
			
				if ((j == i) || (j <= 1) ){
					carray[i-1][j-1] = 1;
				}
				else {
					carray[i-1][j-1] = carray[i-2][j-2] + carray[i-2][j-1];

				}
			}
		}
	
		double[][] binCoefs = carray;
		return binCoefs;
	}
	
	private double[][] CalculateRawMoments(float[] pixels, int width){
		int order = 4;
                int j = order + 1;
		double[][] sum = new double[order][order];
		int sz = pixels.length;
		double factor = 1.0;
		double[][] rawMoments = new double[order][order];
	
		for (int i = 0 ; i < sz ; i++) {
			int x = i%width;
			int y = i/width;
            
			double[] pc = new double[j*j];

			for (int p = 0 ; p < order ; p++) {
				
				for (int q = 0 ; q < order ; q++) {
					
					int index = p * order + q;
					if  (p == 0){
						if (q == 0){
							sum[0][0] += pixels[i]; //volume
							pc[index] = 1;
						}
						else{
							pc[index] = y * pc[q-1];
							sum[p][q] += pixels[i] * pc[index];
						}
					}
					else{
						if (q == 0) {
							pc[index] = x * pc[(p-1)*order];
							sum[p][q] += pixels[i] * pc[index];
						}
						else{
							pc[index] = x * y * pc[(p-1) * order + q - 1];
							sum[p][q] += pixels[i] * pc[index];
						}
					}
				
				}
			}
			
			
		}
		for (int p=0; p<order; p++) {
			for (int q=0; q<order; q++) {
				factor=Math.pow(cal.pixelWidth,p)*Math.pow(cal.pixelHeight,q);
				sum[p][q]*=factor;
			}
			
		}
		rawMoments=sum;
		
		return rawMoments;
	}
	
	private double[][] CalculateCentralMoments(float[] pixels, int width, double[][] rawMoments, double[][] binCoefs){
		int order=4;
                int j = order + 1;
		double[][] centralMoments = new double[order][order];
		double[][] ret = new double[order][order];
		if (order <= 1){
			centralMoments[0][0] = rawMoments[0][0];
			return centralMoments;
		}	
		else{
			double xbar = rawMoments[1][0] / rawMoments[0][0] - 0.5; //continuity correction
			double ybar = rawMoments[0][1] / rawMoments[0][0] - 0.5; //continuity correction
			//getCentroid()[0] = xbar;
			//getCentroid()[1] = ybar;
			for (int p = 0 ; p < order ; p++) {
				for (int q = 0 ; q < order ; q++) {
					double sum = 0;
					for (int m = 0 ; m < rawMoments.length ; m++){
						for (int n = 0 ; n < rawMoments[0].length ; n++){
							sum += binCoef(p, m, binCoefs) * binCoef (q, n, binCoefs) * Math.pow(-xbar, p - m) * Math.pow(-ybar, q - n) * rawMoments[m][n];
						}
					}
					ret[p][q]=sum;
				}
			}
		}
		
		centralMoments = ret;
		return centralMoments;
	}
	
	private double[][] calculateScaledMoments(float[] pixels, int width, double[][] centralMoments) {
		int order = 4;
                int j = order + 1;
		double[][] ret = new double[order][order];
		ret[0][0] = 1;
		
		for (int p = 0 ; p < order ; p++) {
			
			for (int q = 0 ; q < order ; q++) {
				if ((p + q) >= 2)
					ret[p][q] = centralMoments[p][q] / Math.pow(centralMoments[0][0], 1 + (p + q) / 2);
			}
		}

		double[][] scaledMoments = ret;
		return scaledMoments;
	}

	private ImageProcessor getMask(ImageProcessor ip, Rectangle rect) {
		 
		int width;
		int xloc;
		int yloc;
		int w;
		int h;
		int index;
		if (ip instanceof ByteProcessor) {
			
			 width = ip.getWidth();
	       	 byte[] pixels = (byte[])ip.getPixels();
	       	 xloc = (int)rect.getX();
	       	 yloc = (int)rect.getY();
	         w = (int)rect.getWidth();
	         h = (int)rect.getHeight();
	         byte[] mask=new byte[w * h];
	     

	         for (int cnt = 0; cnt < mask.length ; cnt++) {
	            index = xloc + cnt%w + (cnt/w) * width + yloc * width;
	            mask[cnt] = (byte)(pixels[index] & 0xFF);  
	         }
	         return new ByteProcessor(w, h, mask,ip.getColorModel());
		 }
		 else if(ip instanceof ShortProcessor) {
			 width = ip.getWidth();
	    	 short[] pixels = (short[])ip.getPixels();
	    	 xloc = (int)rect.getX();
	    	 yloc = (int)rect.getY();
	    	 w = (int)rect.getWidth();
	    	 h = (int)rect.getHeight();
	    	 short[] mask = new short[w * h];
	   
	    	 for (int cnt = 0; cnt < mask.length ; cnt++) {
	    		 index = xloc + cnt%w + (cnt/w) * width + yloc * width;
	    		 mask[cnt] = pixels[index];  
	    	 }
	    	 return new ShortProcessor(w, h, mask, ip.getColorModel());
		 }
	   	 
	    if (ip instanceof FloatProcessor) {
	    	width = ip.getWidth();
	        float[] pixels = (float[])ip.getPixels();

	      	 
	        xloc = (int)rect.getX();
	        yloc = (int)rect.getY();
	        w = (int)rect.getWidth();
	        h = (int)rect.getHeight();
	        float[] mask=new float[w * h];
	    
	        for (int cnt = 0 ; cnt < mask.length ; cnt++) {
	           index = xloc + cnt%w + (cnt/w) * width + yloc * width;
	           mask[cnt] = pixels[index];  
	                 	
	        }

	        return new FloatProcessor(w, h, mask, ip.getColorModel());
	   	
	    }	 
		 
	    return null;
	}
	private double binCoef(int n, int k, double[][] binCoefs) {
		if (k<0) return 0;
		if (k>n) return 0;
		if (k==0) return 1;
		if (k==n) return 1;

		return binCoefs[n][k];
	}
	
	private float[] CalibratePixels(Object pixels, float[] ctable) {
		
		if (pixels instanceof float[]) {
			return (float[]) pixels;
		}
		
		int sz;
		if (pixels instanceof byte[]) {
			byte[] b = (byte[]) pixels;
			sz = b.length;
			float[] ret = new float [sz];
			for (int i = 0 ; i < sz ; i++ ) {
		 		ret[i] = ctable[b[i] & 0xFF];
			}
			return ret;
		}
		
		if (pixels instanceof short[]) {
			short[] b = (short[]) pixels;
			sz = b.length;
			float[] ret = new float [sz];
			for (int i = 0 ; i < sz ; i++ ) {
				ret[i] = ctable [b[i] & 0xFFF];
			}
			return ret;
		}

		if (pixels instanceof int[]) {
			int[] b = (int[]) pixels;
			sz = b.length;
			float[] ret = new float [sz];
			for (int i = 0 ; i < sz ; i++ ) {
				ret[i] = ctable[b[i] & 0xFFFF];
			}
			return ret;
		}	
				
		return null;
	}
	
	private float[] toFloatPixels(Object pixels){
		
		if (pixels instanceof float[]) 
			return (float[]) pixels;
		
		if (pixels instanceof byte[]) {
			byte[] b = (byte[]) pixels;
			int sz = b.length;
			float[] ret = new float [sz];
			for (int i = 0 ; i < sz ; i++ ) {
				ret[i] = (float)(b[i] & 0xFF);
			}
			return ret;
		}
		
		if (pixels instanceof short[]) {
			short[] b = (short[]) pixels;
			int sz = b.length;
			float[] ret = new float [sz];
			for (int i = 0 ; i < sz ; i++ ) {
				ret[i] = (float)(b[i] & 0xFFF);
			}
			return ret;
		}

		if (pixels instanceof int[]) {
			int[] b = (int[]) pixels;
			int sz = b.length;
			float[] ret = new float [sz];
			for (int i = 0 ; i < sz ; i++ ) {
				ret[i]=(float)(b[i] & 0xFFFF);
			}
			return ret;
		}

		
		return null;
	}
	
	private double[] getCentroid(){
		return centroid;
	}
	public double[] getInvariantMomentsArray(){
		return invariantMoments;
	}
}
