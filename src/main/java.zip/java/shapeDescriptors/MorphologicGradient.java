package shapeDescriptors;
import java.awt.Polygon;
import java.util.ArrayList;

import ij.ImagePlus;
import ij.gui.Roi;
import ij.gui.ShapeRoi;
import ij.plugin.frame.RoiManager;


public class MorphologicGradient {

	private double gradientSum;
	int gradientRange;
	
	public MorphologicGradient(int gradientRange){
	
		this.gradientRange = gradientRange;
	}
		
	public void exec(ImagePlus imp, Roi roi) {
		
		gradientSum = 0;
		ShapeRoi shapeRoi = new ShapeRoi(roi);
		Roi[] rois = shapeRoi.getRois();
		Polygon roiAsPolygon = rois[0].getPolygon();
		int[][] contourArray = new int[2][roiAsPolygon.xpoints.length];
		contourArray[0] = roiAsPolygon.xpoints;
		contourArray[1] = roiAsPolygon.ypoints;
		
		for (int j = gradientRange ; j < contourArray[1].length - gradientRange ; j++){
			
			double gradient = getPerpendicularGradient(contourArray, j, imp, gradientRange);
			gradientSum += gradient;
		}
		gradientSum = gradientSum/contourArray.length;
		
	}
		
		private double getPerpendicularGradient(int[][] contourArray, int i, ImagePlus imp, int gradientRange) {
			
			int dx = contourArray[0][i] - contourArray[0][i-1];
			int dy = contourArray[1][i] - contourArray[1][i-1];
			
			int gradientIntensityX1;
			int gradientIntensityX2;
                        //getPixel; Returns the pixel value at (x,y) as a 4 element array. 
                        //Grayscale values are retuned in the first element.
                        //RGB values are returned in the first 3 elements. 
                        //For indexed color images, the RGB values are returned in the first 3 three elements and the index (0-255) is returned in the last.
			if (dx == 0){
				gradientIntensityX1 = imp.getPixel(contourArray[0][i], contourArray[1][i])[0];
				gradientIntensityX2 = imp.getPixel(contourArray[0][i], contourArray[1][i])[0];
			}
			else{
				gradientIntensityX1 = imp.getPixel(contourArray[0][i], contourArray[1][i + gradientRange])[0];
				gradientIntensityX2 = imp.getPixel(contourArray[0][i], contourArray[1][i - gradientRange])[0];
			}
			int gradientX = gradientIntensityX1 - gradientIntensityX2;
			
			int gradientIntensityY1;
			int gradientIntensityY2;
			if (dy == 0){
				gradientIntensityY1 = imp.getPixel(contourArray[0][i], contourArray[1][i])[0];
				gradientIntensityY2 = imp.getPixel(contourArray[0][i], contourArray[1][i])[0];
			}
			else{
				gradientIntensityY1 = imp.getPixel(contourArray[0][i + gradientRange], contourArray[1][i])[0];
				gradientIntensityY2 = imp.getPixel(contourArray[0][i - gradientRange], contourArray[1][i])[0];
			}
			int gradientY = gradientIntensityY1 - gradientIntensityY2;
			
			double gradient = Math.sqrt(Math.pow(gradientX, 2) + Math.pow(gradientY, 2));

		return gradient;
	}

		private int[][] GetROICoordinates(RoiManager rm, int selectedRoi) {
			Roi[] roi = rm.getRoisAsArray();
			Polygon p = roi[selectedRoi].getPolygon(); 
			
			ArrayList<Integer> ROICoordinatesX = new ArrayList<Integer>();
			ArrayList<Integer> ROICoordinatesY = new ArrayList<Integer>();
			
			for( int i = 0 ; i < p.npoints-1 ; i++){
				
				if (Math.abs(p.xpoints[i] - p.xpoints[i+1]) < 2 && Math.abs(p.ypoints[i] - p.ypoints[i+1]) < 2){

					ROICoordinatesX.add(p.xpoints[i]);
					ROICoordinatesY.add(p.ypoints[i]);
				
				}
				else if (Math.abs(p.xpoints[i] - p.xpoints[i+1]) >= 2 || Math.abs(p.ypoints[i] - p.ypoints[i+1]) >= 2){
				
					ROICoordinatesX.add(p.xpoints[i]);
					ROICoordinatesY.add(p.ypoints[i]);
					
					int pointAddsX = -(p.xpoints[i] - p.xpoints[i+1]);
					int pointAddsY = -(p.ypoints[i] - p.ypoints[i+1]);
					if (Math.abs(p.xpoints[i] - p.xpoints[i+1]) >= Math.abs(p.ypoints[i] - p.ypoints[i+1])){

						for( int j = 1 ; j < Math.abs(pointAddsX) ; j++){
							ROICoordinatesX.add(p.xpoints[i] + j * (pointAddsX/Math.abs(pointAddsX)));
							ROICoordinatesY.add(p.ypoints[i] + Math.round(j * (float)pointAddsY/pointAddsX));
						}
					}
					else{
						for( int j = 1 ; j < Math.abs(pointAddsY) ; j++){
							ROICoordinatesY.add(p.ypoints[i] + j * (pointAddsY/Math.abs(pointAddsY)));
							ROICoordinatesX.add(p.xpoints[i] + Math.round(j * (float)pointAddsX/pointAddsY));
						}
					}
					
				}
			}
			
			int[][] contourArray = new int[2][ROICoordinatesX.size()];
			for ( int i = 0 ; i < ROICoordinatesX.size() ; i++){
				contourArray[0][i] = ROICoordinatesX.get(i);
				contourArray[1][i] = ROICoordinatesY.get(i);
				
			}
			return contourArray;
		}

	public double getGradientSum() {
		
		return gradientSum;
	}

}
