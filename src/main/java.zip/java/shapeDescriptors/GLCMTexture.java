package shapeDescriptors;

import ij.*;
import ij.IJ.*;
import ij.gui.*;
import ij.plugin.filter.PlugInFilter;
import ij.process.*;
import java.awt.*;
import ij.plugin.PlugIn;
import ij.text.*;
import ij.measure.ResultsTable;

//==========================================================
public class GLCMTexture {

    static int d = 1;
    //static int phi = 0;
    static boolean symmetry = true;
    static boolean doASM = true;
    static boolean doContrast = true;
    static boolean doCorrelation = true;
    static boolean doIDM = true;
    static boolean doEntropy = true;
    static boolean doEnergy = true;
    static boolean doInertia = true;
    static boolean doHomogeneity = true;
    static boolean doProminence = true;
    static boolean doVariance = true;
    static boolean doShade = true;

    double[][] textureArray;

    ResultsTable rt = ResultsTable.getResultsTable();
    /*
     public int setup(String arg, ImagePlus imp) {
     if (imp!=null && !showDialog()) return DONE;
     //perhaps not reseting the resultsTable would be better... ??
     rt.reset();
     return DOES_8G+DOES_STACKS+SUPPORTS_MASKING;
     }
     */

    public void exec(ImagePlus imp, Roi inputRoi) {

        textureArray = new double[4][12];

        for (int phi = 0; phi <= 135; phi = phi + 45) {

            rt.reset();

            //ImagePlus imp = IJ.getImage();
            IJ.run(imp, "8-bit", "");
            imp.setRoi(inputRoi);

            ImageProcessor ip = imp.getProcessor();
            ip.setRoi(inputRoi);
            // use the bounding rectangle ROI to roughly limit processing
            Rectangle roi = ip.getRoi();

            // get byte arrays for the image pixels and mask pixels
            int width = ip.getWidth();
            int height = ip.getHeight();
            byte[] pixels = (byte[]) ip.getPixels();
            byte[] mask = ip.getMaskArray();

            // value = value at pixel of interest; dValue = value of pixel at offset    
            int value;
            int dValue;
            double totalPixels = roi.height * roi.width;
            if (symmetry) {
                totalPixels = totalPixels * 2;
            }
            double pixelProgress = 0;
            double pixelCount = 0;
            int pixelDepth = (int) Math.pow(2.0, (double) ip.getBitDepth());

	//====================================================================================================
            //compute the Gray Level Correlation Matrix
            int offsetX = 1;
            int offsetY = 0;
            double[][] glcm = new double[pixelDepth][pixelDepth];

            // set our offsets based on the selected angle
            if (phi == 0) {
                offsetX = d;
                offsetY = 0;
            } else if (phi == 45) {
                offsetX = d;
                offsetY = -d;
            } else if (phi == 90) {
                offsetX = 0;
                offsetY = -d;
            } else if (phi == 135) {
                offsetX = -d;
                offsetY = -d;
            } else {
                // the angle is not one of the options
                IJ.showMessage("The requested angle," + phi + ", is not one of the supported angles (0,45,90,135)");
            }

            // loop through the pixels in the ROI bounding rectangle
            for (int y = roi.y; y < (roi.y + roi.height); y++) {
                for (int x = roi.x; x < (roi.x + roi.width); x++) {
                    // check to see if the pixel is in the mask (if it exists)
                    if ((mask == null) || ((0xff & mask[(((y - roi.y) * roi.width) + (x - roi.x))]) > 0)) {
                        // check to see if the offset pixel is in the roi
                        int dx = x + offsetX;
                        int dy = y + offsetY;
                        if (((dx >= roi.x) && (dx < (roi.x + roi.width))) && ((dy >= roi.y) && (dy < (roi.y + roi.height)))) {
                            // check to see if the offset pixel is in the mask (if it exists) 
                            if ((mask == null) || ((0xff & mask[(((dy - roi.y) * roi.width) + (dx - roi.x))]) > 0)) {
                                value = 0xff & pixels[(y * width) + x];
                                dValue = 0xff & pixels[(dy * width) + dx];
                                glcm[value][dValue]++;
                                pixelCount++;
                            }
                            // if symmetry is selected, invert the offsets and go through the process again
                            if (symmetry) {
                                dx = x - offsetX;
                                dy = y - offsetY;
                                if (((dx >= roi.x) && (dx < (roi.x + roi.width))) && ((dy >= roi.y) && (dy < (roi.y + roi.height)))) {
                                    // check to see if the offset pixel is in the mask (if it exists) 
                                    if ((mask == null) || ((0xff & mask[(((dy - roi.y) * roi.width) + (dx - roi.x))]) > 0)) {
                                        value = 0xff & pixels[(y * width) + x];
                                        dValue = 0xff & pixels[(dy * width) + dx];
                                        glcm[dValue][value]++;
                                        pixelCount++;
                                    }
                                }
                            }
                        }
                    }
                    pixelProgress++;
                }
            }

	//=====================================================================================================
            //convert the GLCM from absolute counts to probabilities
            for (int i = 0; i < pixelDepth; i++) {
                for (int j = 0; j < pixelDepth; j++) {
                    glcm[i][j] = (glcm[i][j]) / (pixelCount);
                }
            }

	//=====================================================================================================
            //calculate meanx, meany, stdevx and stdevy for the glcm
            double[] px = new double[pixelDepth];
            double[] py = new double[pixelDepth];
            double meanx = 0.0;
            double meany = 0.0;
            double stdevx = 0.0;
            double stdevy = 0.0;

		// Px(i) and Py(j) are the marginal-probability matrix; sum rows (px) or columns (py) 
            // First, initialize the arrays to 0
            for (int i = 0; i < pixelDepth; i++) {
                px[i] = 0.0;
                py[i] = 0.0;
            }

            // sum the glcm rows to Px(i)
            for (int i = 0; i < pixelDepth; i++) {
                for (int j = 0; j < pixelDepth; j++) {
                    px[i] += glcm[i][j];
                }
            }

            // sum the glcm rows to Py(j)
            for (int j = 0; j < pixelDepth; j++) {
                for (int i = 0; i < pixelDepth; i++) {
                    py[j] += glcm[i][j];
                }
            }

            // calculate meanx and meany
            for (int i = 0; i < pixelDepth; i++) {
                meanx += (i * px[i]);
                meany += (i * py[i]);
            }

            // calculate stdevx and stdevy
            for (int i = 0; i < pixelDepth; i++) {
                stdevx += ((Math.pow((i - meanx), 2)) * px[i]);
                stdevy += ((Math.pow((i - meany), 2)) * py[i]);
            }

            int row = rt.getCounter();
            rt.incrementCounter();
	//=====================================================================================================
            //calculate the angular second moment (asm)

            if (doASM == true) {
                double asm = 0.0;
                for (int i = 0; i < pixelDepth; i++) {
                    for (int j = 0; j < pixelDepth; j++) {
                        asm += (glcm[i][j] * glcm[i][j]);
                    }
                }
                rt.setValue("Angular Second Moment", row, asm);
                textureArray[(int) (phi / 45)][0] = asm;
            }

	//=====================================================================================================
            //This is the generic moments function from parker -- may implement in the future
            //k is the power for the moment
            /*
             if (doMoments == true){
             double y=0.0;
             double z;
             double k;
             double moments = 0.0;
	
             for (int i=0;  i<pixelDepth; i++)  {
             for (int j=0; j<pixelDepth; j++) {
             if (k>0) {
             z = Math.pow ((i-j), k);
             } else {
             if (i == j) continue;
             z = Math.pow ((i-j), -1*k);
             z = glcm[i][j]/z;
             }
             moments += z * glcm[i][j];
             }
             }
             rt.setValue("Angular Second Moment", row, asm);
             }
             */
	//===============================================================================================
            //calculate the inverse difference moment (idm) (Walker, et al. 1995)
            //this is calculated using the same formula as Conners, et al., 1984 "Local Homogeneity"
            if (doIDM == true) {
                double IDM = 0.0;
                for (int i = 0; i < pixelDepth; i++) {
                    for (int j = 0; j < pixelDepth; j++) {
                        IDM += ((1 / (1 + (Math.pow(i - j, 2)))) * glcm[i][j]);
                    }
                }
                rt.setValue("Inverse Difference Moment", row, IDM);
                textureArray[(int) (phi / 45)][1] = IDM;
            }

	//===============================================================================================
            //calculate the diagonal moment (looking for the reference)
	/*
             if (doDiagonalMoment == true){
             double diagonalMoment = 0.0;
             for (int i=0;  i<pixelDepth; i++)  {
             for (int j=0; j<pixelDepth; j++) {
             //    diagm  += (double) (abs(y-x)*( (y-1) + (x-1) - mux - muy )*inband[y][x]);
             diagonalMoment += (Math.abs(i-j)*( (i-1) + (j-1) - meanx - meany )*glcm[i][j]);
             }
             }
             rt.setValue("Diagonal Moment", row, diagonalMoment);
             }
             */
	//=====================================================================================================
            //calculate the contrast (Haralick, et al. 1973)
            //similar to the inertia, except abs(i-j) is used
            if (doContrast == true) {
                double contrast = 0.0;

                for (int i = 0; i < pixelDepth; i++) {
                    for (int j = 0; j < pixelDepth; j++) {
                        contrast += Math.pow(Math.abs(i - j), 2) * (glcm[i][j]);
                    }
                }
                rt.setValue("Contrast", row, contrast);
                textureArray[(int) (phi / 45)][2] = contrast;
            }

	//===============================================================================================
            //calculate the energy
            if (doEnergy == true) {
                double energy = 0.0;
                for (int i = 0; i < pixelDepth; i++) {
                    for (int j = 0; j < pixelDepth; j++) {
                        energy += Math.pow(glcm[i][j], 2);
                    }
                }
                rt.setValue("Energy", row, energy);
                textureArray[(int) (phi / 45)][3] = energy;
            }

	//===============================================================================================
            //calculate the entropy (Haralick et al., 1973; Walker, et al., 1995)
            if (doEntropy == true) {
                double entropy = 0.0;
                for (int i = 0; i < pixelDepth; i++) {
                    for (int j = 0; j < pixelDepth; j++) {
                        if (glcm[i][j] != 0) {
                            entropy = entropy - (glcm[i][j] * (Math.log(glcm[i][j])));
						//the next line is how Xite calculates it -- I am not sure why they use this, I do not think it is correct
                            //(they also use log base 10, which I need to implement)
                            //entropy = entropy-(glcm[i][j]*((Math.log(glcm[i][j]))/Math.log(2.0)) );
                        }
                    }
                }
                rt.setValue("Entropy", row, entropy);
                textureArray[(int) (phi / 45)][4] = entropy;
            }
	//===============================================================================================
            //calculate the homogeneity (Parker)
            //"Local Homogeneity" from Conners, et al., 1984 is calculated the same as IDM above
            //Parker's implementation is below; absolute value of i-j is taken rather than square

            if (doHomogeneity == true) {
                double homogeneity = 0.0;
                for (int i = 0; i < pixelDepth; i++) {
                    for (int j = 0; j < pixelDepth; j++) {
                        homogeneity += glcm[i][j] / (1.0 + Math.abs(i - j));
                    }
                }
                rt.setValue("Homogeneity", row, homogeneity);
                textureArray[(int) (phi / 45)][5] = homogeneity;
            }
	//===============================================================================================
            //calculate the variance ("variance" in Walker 1995; "Sum of Squares: Variance" in Haralick 1973)

            if (doVariance == true) {
                double variance = 0.0;
                double mean = 0.0;

                mean = (meanx + meany) / 2;
                /*
                 // this is based on xite, and is much greater than the actual mean -- it is here for reference only
                 for (int i=0;  i<pixelDepth; i++)  {
                 for (int j=0; j<pixelDepth; j++) {
                 mean += glcm[i][j]*i*j;
                 }
                 }
                 */

                for (int i = 0; i < pixelDepth; i++) {
                    for (int j = 0; j < pixelDepth; j++) {
                        variance += (Math.pow((i - mean), 2) * glcm[i][j]);
                    }
                }
                rt.setValue("Variance", row, variance);
                textureArray[(int) (phi / 45)][6] = variance;
            }

	//===============================================================================================
            //calculate the shade (Walker, et al., 1995; Connors, et al. 1984)
            if (doShade == true) {
                double shade = 0.0;

                // calculate the shade parameter
                for (int i = 0; i < pixelDepth; i++) {
                    for (int j = 0; j < pixelDepth; j++) {
                        shade += (Math.pow((i + j - meanx - meany), 3) * glcm[i][j]);
                    }
                }
                rt.setValue("Shade", row, shade);
                textureArray[(int) (phi / 45)][7] = shade;
            }

	//==============================================================================================
            //calculate the prominence (Walker, et al., 1995; Connors, et al. 1984)
            if (doProminence == true) {

                double prominence = 0.0;

                for (int i = 0; i < pixelDepth; i++) {
                    for (int j = 0; j < pixelDepth; j++) {
                        prominence += (Math.pow((i + j - meanx - meany), 4) * glcm[i][j]);
                    }
                }
                rt.setValue("Prominence", row, prominence);
                textureArray[(int) (phi / 45)][8] = prominence;
            }

	//===============================================================================================
            //calculate the inertia (Walker, et al., 1995; Connors, et al. 1984)
            if (doInertia == true) {
                double inertia = 0.0;
                for (int i = 0; i < pixelDepth; i++) {
                    for (int j = 0; j < pixelDepth; j++) {
                        if (glcm[i][j] != 0) {
                            inertia += (Math.pow((i - j), 2) * glcm[i][j]);
                        }
                    }
                }
                rt.setValue("Inertia", row, inertia);
                textureArray[(int) (phi / 45)][9] = inertia;
            }
	//=====================================================================================================
            //calculate the correlation
            //methods based on Haralick 1973 (and MatLab), Walker 1995 are included below
            //Haralick/Matlab result reported for correlation currently; will give Walker as an option in the future

            if (doCorrelation == true) {
                double correlation = 0.0;

                // calculate the correlation parameter
                for (int i = 0; i < pixelDepth; i++) {
                    for (int j = 0; j < pixelDepth; j++) {
					//Walker, et al. 1995 (matches Xite)
                        //correlation += ((((i-meanx)*(j-meany))/Math.sqrt(stdevx*stdevy))*glcm[i][j]);
                        //Haralick, et al. 1973 (continued below outside loop; matches original GLCM_Texture)
                        //correlation += (i*j)*glcm[i][j];
                        //matlab's rephrasing of Haralick 1973; produces the same result as Haralick 1973
                        correlation += ((((i - meanx) * (j - meany)) / (stdevx * stdevy)) * glcm[i][j]);
                    }
                }
			//Haralick, et al. 1973, original method continued.
                //correlation = (correlation -(meanx*meany))/(stdevx*stdevy);

                rt.setValue("Correlation", row, correlation);
                textureArray[(int) (phi / 45)][10] = correlation;
            }

	//===============================================================================================
            // calculate the sum of all glcm elements
            double sum = 0.0;
            for (int i = 0; i < pixelDepth; i++) {
                for (int j = 0; j < pixelDepth; j++) {
                    sum = sum + glcm[i][j];
                }
            }
            rt.setValue("Sum of all GLCM elements", row, sum);
            textureArray[(int) (phi / 45)][11] = sum;
            //rt.show("Results");
        }

    }

    public double[][] getTextureArray() {
        return textureArray;
    }

}
