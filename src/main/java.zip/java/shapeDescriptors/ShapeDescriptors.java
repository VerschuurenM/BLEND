package shapeDescriptors;

import java.awt.Rectangle;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;

import javax.swing.JFileChooser;

import segmentation.Segmentation;

import ij.IJ;
import ij.ImagePlus;
import ij.gui.Roi;
import ij.plugin.PlugIn;
import ij.plugin.frame.RoiManager;
import ij.io.Opener;
import initialConfiguration.InitialConfiguration;

public class ShapeDescriptors {// implements PlugIn {

    String inputDirectory;
    String outputDirectory;
    Segmentation SegmentationObject;
    ArrayList<int[]> roiList;
    int curvature;
    int fourierDescriptor;
    int gradients;

    boolean notOverwrite;

    public ShapeDescriptors(InitialConfiguration InitialConfigurationObject, Segmentation SegmentationObject) {
        this.inputDirectory = InitialConfigurationObject.getInputDirectory();
        this.outputDirectory = InitialConfigurationObject.getOutputDirectory();
        this.SegmentationObject = SegmentationObject;
        this.curvature = InitialConfigurationObject.getCurvature();
        this.fourierDescriptor = InitialConfigurationObject.getFourier();
        this.gradients = InitialConfigurationObject.getGradients();
    }

    public void exec() {

        StandardImageJDescriptors StandardImageJDescriptorsObject = new StandardImageJDescriptors();
        Curvature CurvatureObject = new Curvature();
        EllipticFD EllipticFDObject = new EllipticFD(fourierDescriptor);
        HuInvariantMoments HuInvariantMomentsObject = new HuInvariantMoments();
        MorphologicGradient MorphologicGradientObject = new MorphologicGradient(gradients);
        GLCMTexture GLCMTextureObject = new GLCMTexture();

        ArrayList<String> imageArray = getImageArray(inputDirectory);
        LoadRoiList();

        SetUpOutputFile(outputDirectory);

        for (int imagesInArray = 0; imagesInArray < imageArray.size(); imagesInArray++) {

            ImagePlus imp = IJ.openImage(inputDirectory + imageArray.get(imagesInArray));

            SegmentationObject.exec(imp);
            Roi[] roiArray = SegmentationObject.getRoiArray();

            for (int roiImpCounter = 0; roiImpCounter < roiArray.length; roiImpCounter++) {

                Rectangle rect = roiArray[roiImpCounter].getBounds();

                int roiHeight = rect.height;
                int roiWidth = rect.width;
                int roiX = rect.x;
                int roiY = rect.y;
                int roiClass = -1;

                for (int roiListCounter = 0; roiListCounter < roiList.size(); roiListCounter++) {
                    int[] roiListArray = roiList.get(roiListCounter);
                    if (roiListArray[0] == roiImpCounter && roiListArray[1] == roiHeight && roiListArray[2] == roiWidth
                            && roiListArray[3] == roiX && roiListArray[4] == roiY) {

                        roiClass = roiListArray[5];
                        roiListCounter = roiList.size();

                    }
                }

                if (roiClass == -1) {
                    break;
                }

                StandardImageJDescriptorsObject.exec(imp, roiArray[roiImpCounter]);
                double[] standardDescriptors = StandardImageJDescriptorsObject.getStandardDescriptors();

                ArrayList<double[]> curvatureDescriptorsPackage = new ArrayList<double[]>();
                double[] curvatureDescriptors;
                for (int i = 1; i <= curvature; i++) {
                    CurvatureObject.exec(imp, roiArray[roiImpCounter], i);
                    curvatureDescriptors = CurvatureObject.getCurvatureDescriptors();
                    curvatureDescriptorsPackage.add(curvatureDescriptors);
                }

                EllipticFDObject.exec(roiArray[roiImpCounter]);
                double[][] ellipticFD = EllipticFDObject.getEllipticFourierDescriptors();

                HuInvariantMomentsObject.exec(imp, roiArray[roiImpCounter]);
                double[] huInvariantMoments = HuInvariantMomentsObject.getInvariantMomentsArray();

                MorphologicGradientObject.exec(imp, roiArray[roiImpCounter]);
                double gradientSum = MorphologicGradientObject.getGradientSum();

                GLCMTextureObject.exec(imp, roiArray[roiImpCounter]);
                double[][] textureArray = GLCMTextureObject.getTextureArray();

                FileWrite(Integer.toString(roiClass) + ";", outputDirectory);

                for (int n = 0; n < standardDescriptors.length; n++) {
                    FileWrite(Double.toString(standardDescriptors[n]) + ";", outputDirectory);
                }
                for (int n = 0; n < curvature; n++) {
                    for (int m = 0; m < curvatureDescriptorsPackage.get(n).length; m++) {
                        FileWrite(Double.toString(curvatureDescriptorsPackage.get(n)[m]) + ";", outputDirectory);
                    }
                }
                for (int n = 0; n < ellipticFD[0].length; n++) {
                    for (int m = 0; m < 5; m++) {
                        FileWrite(Double.toString(ellipticFD[m][n]) + ";", outputDirectory);
                    }
                }
                for (int n = 0; n < 7; n++) {
                        FileWrite(Double.toString(huInvariantMoments[n]) + ";", outputDirectory);
                }
                FileWrite(Double.toString(gradientSum) + ";", outputDirectory);

                for (int n = 0; n < textureArray.length; n++) {
                    for (int m = 0; m < textureArray[0].length; m++) {
                        FileWrite(Double.toString(textureArray[n][m]) + ";", outputDirectory);
                    }
                }

                FileWrite("\r\n", outputDirectory);
            }
        }
    }

    private void SetUpOutputFile(String outputDirectory) {
        notOverwrite = false;
        FileWrite("Class;", outputDirectory);
        notOverwrite = true;

        FileWrite("Area;Perimeter;Major;Minor;Angle;Feret;Min Feret;Feret Angle;Circularity;Aspect Ratio;Roundness;Solidity;", outputDirectory);

        for (int n = 0; n < curvature; n++) {
            FileWrite("Curvature " + (n + 1) + ";Tilt " + (n + 1) + "; Angle " + (n + 1) + ";", outputDirectory);

        }
        for (int n = 0; n < fourierDescriptor; n++) {
            FileWrite("ax " + (n + 1) + ";ay " + (n + 1) + ";bx " + (n + 1) + ";by " + (n + 1) + ";efd " + (n + 1) + ";", outputDirectory);

        }
        for (int m = 0; m < 7; m++) {
            FileWrite("Hu_invariant_moment-" + (m+1) + ";", outputDirectory);
        }
        FileWrite("Gradient;", outputDirectory);

        for (int n = 0; n <= 135; n = n + 45) {
            FileWrite("Angular Second Moment " + n + ";Inverse Difference Moment " + n + ";Contrast " + n + ";Energy " + n + ";Entropy " + n
                    + ";Homogeneity " + n + ";Variance " + n + ";Shade " + n + ";Prominence " + n + ";Inertia " + n
                    + ";Correlation " + n + ";Sum of all GLCM elements " + n + ";", outputDirectory);
        }

        FileWrite("\r\n", outputDirectory);

    }

    private void Stop() {
        System.exit(0);

    }

    public void FileWrite(String parameters, String outputDirectory) {
        try {
            // Create file 
            FileWriter fstream = new FileWriter(outputDirectory + "parameters.txt", notOverwrite);
            BufferedWriter out = new BufferedWriter(fstream);
            out.write(parameters);
            //Close the output stream
            out.close();
        } catch (Exception e) {//Catch exception if any
            System.err.println("Error: " + e.getMessage());
        }
    }

    private ArrayList<String> getImageArray(String directoryName) {
        String[] fileArray = new File(directoryName).list();

        Arrays.sort(fileArray);

        ArrayList<String> imageArray = new ArrayList<String>();
        for (int i = 0; i < fileArray.length; i++) {
            if (fileArray[i].indexOf(".tif") > 0 || fileArray[i].indexOf(".dcm") > 0 || fileArray[i].indexOf(".fits") > 0
                    || fileArray[i].indexOf(".fit") > 0 || fileArray[i].indexOf(".fts") > 0 || fileArray[i].indexOf(".pgm") > 0
                    || fileArray[i].indexOf(".jpg") > 0 || fileArray[i].indexOf(".jpeg") > 0 || fileArray[i].indexOf(".bmp") > 0) {

                imageArray.add(fileArray[i]);
            }
        }
        return imageArray;
    }

    private void LoadRoiList() {
        roiList = new ArrayList<int[]>();
        String[] myListSources2 = new File(inputDirectory).list();
        for (int i = 0; i < myListSources2.length; i++) {
            String fileName = myListSources2[i];
            if (fileName.indexOf("Morph.txt") >= 0) {
                try {
                    FileInputStream fstream = new FileInputStream(inputDirectory + "Morph.txt");
                    DataInputStream in = new DataInputStream(fstream);
                    BufferedReader br = new BufferedReader(new InputStreamReader(in));
                    String strLine;
                    while ((strLine = br.readLine()) != null) {

                        int previousSemicolon = strLine.indexOf(";");
                        int[] roiParameters = new int[6];
                        int lala = strLine.indexOf(";", previousSemicolon + 1);

                        int inc = 0;
                        while (strLine.indexOf(";", previousSemicolon + 1) >= 0) {
                            roiParameters[inc] = Integer.parseInt(strLine.substring(strLine.indexOf(";", previousSemicolon) + 1, (strLine.indexOf(";", previousSemicolon + 1))));
                            inc += 1;
                            previousSemicolon = strLine.indexOf(";", previousSemicolon + 1);
                        }
                        roiList.add(roiParameters);
                    }

                } catch (Exception e) {
                    System.err.println("Error: " + e.getMessage());
                }
            }
        }
    }

}
