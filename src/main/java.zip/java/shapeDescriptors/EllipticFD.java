package shapeDescriptors;

import ij.gui.*;

import java.awt.*;

import ij.plugin.frame.RoiManager;
import ij.measure.*;


public class EllipticFD{
	
	double[][] ellipticFDArray;
	int nFD;
	
	public EllipticFD(int fourierDescriptor){
		this.nFD = fourierDescriptor;
	}
	
	public void exec(Roi roiInput){
		ellipticFDArray = new double [5][nFD];
		PolygonRoi roi;
		try{
			roi = (PolygonRoi) roiInput;
		}
		catch(Exception e){
			Polygon ala = roiInput.getPolygon();
			roi = new PolygonRoi(ala, Roi.POLYGON);
		}
		Rectangle rect = roi.getBounds();
		  
		int n = roi.getNCoordinates();
		double[] x = new double[n];
		double[] y = new double[n];
		int[] xp = roi.getXCoordinates();
		int[] yp = roi.getYCoordinates();
	  
		for (int j = 0; j < n; j++){
			x[j] = (double) (rect.x + xp[j]);
			y[j] = (double) (rect.y + yp[j]); 
		}
	  
		ellipticFDArray = computeEllipticFD(x, y, nFD);
		
	}
	
	public double[][] getEllipticFourierDescriptors() {
		return ellipticFDArray;
	}
	
	private double[][] computeEllipticFD(double[] x, double[] y, int nFD){
		   
            double[] ax = new double[nFD];	// Fourier Descriptor
	    double[] ay = new double[nFD];	// Fourier Descriptor
	    double[] bx = new double[nFD];	// Fourier Descriptor
	    double[] by = new double[nFD];	// Fourier Descriptor
	     
	    double t = 2.0*Math.PI/x.length;
	    double p = 0.0;
	    double M = 2.0/x.length;;

	    for (int k = 0; k < nFD; k++){

	    	for (int i = 0; i < x.length; i++){
	    		p = k*t*i;
	    		ax[k] +=  x[i]*Math.cos(p);
	    		bx[k] +=  x[i]*Math.sin(p);
	    		ay[k] +=  y[i]*Math.cos(p);
	    		by[k] +=  y[i]*Math.sin(p);
	    	}
	      

	      ax[k] *= M;
	      bx[k] *= M;
	      ay[k] *= M;
	      by[k] *= M;
	      
	    }
	    
	    double[] efd = new double[nFD];		//normalized Elliptic Fourier Descriptor
	    double denomA = (ax[1]*ax[1]) + (ay[1]*ay[1]);
	    double denomB = (bx[1]*bx[1]) + (by[1]*by[1]);
	    for (int k = 0; k < nFD; k++){
	    	efd[k] = Math.sqrt((ax[k]*ax[k] + ay[k]*ay[k])/denomA) + Math.sqrt((bx[k]*bx[k] + by[k]*by[k])/denomB);
	    }
	    
	    double[][] returnMatrix = new double[5][nFD];
	    returnMatrix[0] = ax;
	    returnMatrix[1] = ay;
	    returnMatrix[2] = bx;
	    returnMatrix[3] = by;
	    returnMatrix[4] = efd;

	      
	return returnMatrix;          
	}
 

}