
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import GUI.*;

import segmentation.Segmentation;
import segmentation.getColor;
import java.awt.Color;
import shapeDescriptors.ShapeDescriptors;
import ij.IJ;
import ij.Prefs;
import ij.ImagePlus;
import ij.gui.Roi;
import ij.gui.Overlay;
import ij.io.RoiDecoder;
import ij.plugin.PlugIn;
import ij.plugin.frame.RoiManager;
import initialConfiguration.InitialConfiguration;
import ij.process.ImageProcessor;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Comparator;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import segmentationComparison.SegmentationComparison;
import segmentationComparison.SegmentationComparisonNegCtrl;

public class Marlies_Plugin implements PlugIn {

    ArrayList<String> buttonNames;
    ArrayList<String> GTDirectory;

    boolean smoothing;
    boolean watershed;
    boolean blackBackground;
    int dilations;
    int numberThreshold;
    int globalThresholdMethod;
    int localThresholdMethod;
    int functionality;
    int thresholdingMethods = 14;

    String inputDirectory;
    String outputDirectory;

    public void run(String arg) {

        blackBackground = Prefs.blackBackground;
        //Get all configuration-parameters from config-file
        InitialConfiguration InitialConfigurationObject = new InitialConfiguration();
        getAll(InitialConfigurationObject);

        //Functionality = 0: Segmentation
        if (functionality == 0) {
            //New SegmentationObject
            Segmentation SegmentationObject = new Segmentation(numberThreshold,globalThresholdMethod, localThresholdMethod, smoothing, watershed, dilations,blackBackground);
            //Array with all the names of the image-files in the inputdirectory
            ArrayList<String> imageArray = getImageArray(inputDirectory);
            //Loop over every image -> ImagePlus (Imageprocessor + metadata) -> Segmentation -> RoiArray -> RoiManager
            for (int imagesInArray = 0; imagesInArray < imageArray.size(); imagesInArray++) {

                ImagePlus imp = IJ.openImage(inputDirectory + imageArray.get(imagesInArray));
                SegmentationObject.exec(imp);
                Roi[] roiArray = SegmentationObject.getRoiArray();
                Overlay overlay = new Overlay();

                for (int i = 0; i < roiArray.length; i++) {
                    overlay.add(roiArray[i]);
                }
                imp.show();
                imp.setOverlay(overlay);
                //IJ.save(imp, "/Users/marliesverschuuren/Dropbox/Thesis_Marlies/RESULT_23-12-2014/"+imp.getTitle()+".tiff");
//                getColor gC = new getColor();
//                for (int i = 0; i < roiArray.length; i++) {
//                    Color color = gC.exec(i);
//                    roiArray[i].setStrokeColor(color);
//                    overlay.add(roiArray[i]);
//                }
//
//                imp.show();
//                imp.setOverlay(overlay);
                //IJ.save(imp, "/Users/marliesverschuuren/Dropbox/Thesis_Marlies/Resultaten/Segmentatie/"+imp.getTitle()+".tiff");
            }
        } //Functionality = 1: GUI
        else if (functionality == 1) {
            //New SegmentationObject
            Segmentation SegmentationObject = new Segmentation(numberThreshold,globalThresholdMethod, localThresholdMethod, smoothing, watershed, dilations, blackBackground);
            //New ClassificationGUIObject
            ClassificationGUI ClassificationGUIObject = new ClassificationGUI(SegmentationObject, buttonNames, inputDirectory);
            ClassificationGUIObject.exec();
        } //Functionality = 2: ShapeDescriptors    
        else if (functionality == 2) {
            //New SegmentationObject
            Segmentation SegmentationObject = new Segmentation(numberThreshold,globalThresholdMethod, localThresholdMethod, smoothing, watershed, dilations, blackBackground);
            //New ShapeDescriptorsObject
            ShapeDescriptors ShapeDescriptorsObject = new ShapeDescriptors(InitialConfigurationObject, SegmentationObject);
            ShapeDescriptorsObject.exec();
        } else if (functionality == 3) {
            
            Double[][] parameterArray= new Double[1][1];
            if(numberThreshold==2){
                parameterArray = new Double[thresholdingMethods * thresholdingMethods + GTDirectory.size() * GTDirectory.size()][6];
                parameterArray = TwoThresholdingComparison(parameterArray);
                parameterArray = GroundTruthComparison_TwoThreshold(parameterArray);
            }
            else{
                parameterArray = new Double[thresholdingMethods + GTDirectory.size() * GTDirectory.size()][6];
                parameterArray = OneThresholdingComparison(parameterArray);
                parameterArray = GroundTruthComparison_OneThreshold(parameterArray);
            }

            IJ.log("Thresholding or Ground truth, Global method, Local method, Extra fraction, Hausdorff distance, Averaged HD, Overlap index, Similarity index");

            //Print array with the parameter score of each thresholding method
            for (int i = 0; i < parameterArray.length; i++) {
                int gMethod;
                int lMethod;
                String thresholdingGT;
                if (parameterArray[i][0] < thresholdingMethods * thresholdingMethods) {
                    gMethod = parameterArray[i][0].intValue() / thresholdingMethods;
                    lMethod = parameterArray[i][0].intValue() % thresholdingMethods;
                    thresholdingGT = "thresholding";
                } else {
                    gMethod = (parameterArray[i][0].intValue() - (thresholdingMethods * thresholdingMethods)) / GTDirectory.size();
                    lMethod = (parameterArray[i][0].intValue() - (thresholdingMethods * thresholdingMethods)) % GTDirectory.size();
                    thresholdingGT = "GT";
                }
                IJ.log(thresholdingGT + ", " + Integer.toString(gMethod) + ", " + Integer.toString(lMethod) + ", " + parameterArray[i][1].toString() + ", " + parameterArray[i][2].toString() + ", " + parameterArray[i][3].toString() + ", " + parameterArray[i][4].toString() + ", " + parameterArray[i][5].toString());
                //IJ.log(Double.toString(parameterArrayDouble[rankingSummed[i][0]][1]) + ", " + Double.toString(parameterArrayDouble[rankingSummed[i][0]][1])));
            }

            //Double[][] parameterArray = {{0.0 , 15.0, 24.0},{1.0, 20.0, 24.0},{2.0,1.0, 23.0}};
            //int[][] ranking = new int[3][2];
            //Double[][] parameterArrayDouble = parameterArray;
            int[][] ranking = new int[parameterArray.length][parameterArray[0].length - 1];
            for (int i = 1; i < parameterArray[0].length; i++) {
                parameterArray = SortArray(parameterArray, i);
                for (int j = 0; j < parameterArray.length; j++) {
                    if (i <= 3) {
                        ranking[Double.valueOf(parameterArray[j][0]).intValue()][i - 1] = j;
                    } else {
                        ranking[Double.valueOf(parameterArray[j][0]).intValue()][i - 1] = parameterArray.length - 1 - j;
                    }

                }
            }

            Integer[][] rankingSummed = new Integer[ranking.length][2];
            for (int i = 0; i < ranking.length; i++) {
                rankingSummed[i][0] = i;
                rankingSummed[i][1] = 0;
                for (int j = 0; j < ranking[0].length; j++) {
                    rankingSummed[i][1] += ranking[i][j];
                }

            }
            Arrays.sort(rankingSummed, new Comparator<Integer[]>() {
                public int compare(Integer[] int1, Integer[] int2) {
                    Integer numOfKeys1 = int1[1];
                    Integer numOfKeys2 = int2[1];
                    return numOfKeys1.compareTo(numOfKeys2);
                }
            });

            //Print array with the ranking score of each thresholding method
            for (int i = 0; i < rankingSummed.length; i++) {
                int gMethod;
                int lMethod;
                String thresholdingGT;
                if (rankingSummed[i][0] < thresholdingMethods * thresholdingMethods) {
                    gMethod = rankingSummed[i][0] / thresholdingMethods;
                    lMethod = rankingSummed[i][0] % thresholdingMethods;
                    thresholdingGT = "thresholding";
                } else {
                    gMethod = (rankingSummed[i][0] - (thresholdingMethods * thresholdingMethods)) / GTDirectory.size();
                    lMethod = (rankingSummed[i][0] - (thresholdingMethods * thresholdingMethods)) % GTDirectory.size();
                    thresholdingGT = "GT";
                }
                IJ.log(thresholdingGT + ", " + Integer.toString(gMethod) + ", " + Integer.toString(lMethod));
                //IJ.log(Double.toString(parameterArrayDouble[rankingSummed[i][0]][1]) + ", " + Double.toString(parameterArrayDouble[rankingSummed[i][0]][1])));
            }

        } else if (functionality == 4) {
            String[] roiSources = new File(GTDirectory.get(0)).list();
            ArrayList<String> imageArray = getImageArray(inputDirectory);
            int totalNrNoise = imageArray.size() / roiSources.length;
            Double[][] parameterArray = new Double[totalNrNoise][7];
            parameterArray = NoiseComparison(parameterArray, imageArray);

            IJ.log("NrNoise, Extra fraction, Hausdorff distance, Averaged HD, Overlap index, Similarity index");

            //Print array with the parameter score of each thresholding method
            for (int i = 0; i < parameterArray.length; i++) {
                String name = imageArray.get(i);
                String noise = name.substring(7);
                IJ.log(noise + ", " + parameterArray[i][1].toString() + ", " + parameterArray[i][2].toString() + ", " + parameterArray[i][3].toString() + ", " + parameterArray[i][4].toString() + ", " + parameterArray[i][5].toString());
            }

            int[][] ranking = new int[parameterArray.length][parameterArray[0].length - 1];
            for (int i = 1; i < parameterArray[0].length; i++) {
                parameterArray = SortArray(parameterArray, i);
                for (int j = 0; j < parameterArray.length; j++) {
                    if (i <= 3) {
                        ranking[Double.valueOf(parameterArray[j][0]).intValue()][i - 1] = j;
                    } else {
                        ranking[Double.valueOf(parameterArray[j][0]).intValue()][i - 1] = parameterArray.length - 1 - j;
                    }

                }
            }

            Integer[][] rankingSummed = new Integer[ranking.length][2];
            for (int i = 0; i < ranking.length; i++) {
                rankingSummed[i][0] = i;
                rankingSummed[i][1] = 0;
                for (int j = 0; j < ranking[0].length; j++) {
                    rankingSummed[i][1] += ranking[i][j];
                }

            }
            Arrays.sort(rankingSummed, new Comparator<Integer[]>() {
                public int compare(Integer[] int1, Integer[] int2) {
                    Integer numOfKeys1 = int1[1];
                    Integer numOfKeys2 = int2[1];
                    return numOfKeys1.compareTo(numOfKeys2);
                }
            });

            //Print array with the ranking score of each thresholding method
            for (int i = 0; i < rankingSummed.length; i++) {
                String name = imageArray.get(rankingSummed[i][0]);
                String noise = name.substring(7);
                IJ.log(noise + " ");
                //IJ.log(Double.toString(parameterArrayDouble[rankingSummed[i][0]][1]) + ", " + Double.toString(parameterArrayDouble[rankingSummed[i][0]][1])));
            }
        }
        else if (functionality == 5) {
            
            Double[] AveragedParameterArray = new Double[5];
            AveragedParameterArray= GroundTruthComparison_NegCtrl();
            IJ.log("Extra fraction, Hausdorff distance, Averaged HD, Overlap index, Similarity index");
            IJ.log(AveragedParameterArray[0].toString() + ", " + AveragedParameterArray[1].toString() + ", " + AveragedParameterArray[2].toString() + ", " + AveragedParameterArray[3].toString() + ", " + AveragedParameterArray[4].toString());

        }
    }

   

        private Double[][] GroundTruthComparison_OneThreshold(Double[][] parameterArray) {

        SegmentationComparison ExtractParametersObject = new SegmentationComparison();

        ArrayList<String> imageArray = getImageArray(inputDirectory);

        for (int groundTruth1 = 0; groundTruth1 < GTDirectory.size(); groundTruth1++) {
            for (int groundTruth2 = 0; groundTruth2 < GTDirectory.size(); groundTruth2++) {

                IJ.log(Integer.toString(groundTruth1) + ", " + Integer.toString(groundTruth2));

                double extraFractionAveraged = 0;
                double hddMaxAveraged = 0;
                double hddSumAveraged = 0;
                double overlapIndexAveraged = 0;
                double similarityIndexAveraged = 0;
                double inc = 0;

                for (int imagesInArray = 0; imagesInArray < imageArray.size(); imagesInArray++) {

                    ArrayList<Roi[]> GTRoisList = new ArrayList<Roi[]>();
                    for (int i = 0; i < GTDirectory.size(); i++) {
                        String[] roiSources = new File(GTDirectory.get(i)).list();
                        Arrays.sort(roiSources);
                        GTRoisList.add(GetGTRois(GTDirectory.get(i) + roiSources[imagesInArray]));

                    }
                    ExtractParametersObject.exec(GTRoisList.get(groundTruth2), GTRoisList.get(groundTruth1));

                    double[] extraFractionImageArray = ExtractParametersObject.getExtraFractionImageArray();
                    double[] hddMaxImageArray = ExtractParametersObject.getHddMaxImageArray();
                    double[] hddSumImageArray = ExtractParametersObject.getHddSumImageArray();
                    double[] overlapIndexImageArray = ExtractParametersObject.getOverlapIndexImageArray();
                    double[] similarityIndexImageArray = ExtractParametersObject.getSimilarityIndexImageArray();

                    for (int cellCount = 0; cellCount < extraFractionImageArray.length; cellCount++) {
                        extraFractionAveraged += extraFractionImageArray[cellCount];
                        hddMaxAveraged += hddMaxImageArray[cellCount];
                        hddSumAveraged += hddSumImageArray[cellCount];
                        overlapIndexAveraged += overlapIndexImageArray[cellCount];
                        similarityIndexAveraged += similarityIndexImageArray[cellCount];

                        inc += 1;

                    }

                }

                parameterArray[thresholdingMethods + groundTruth1 * GTDirectory.size() + groundTruth2][0] = (double) (thresholdingMethods + groundTruth1 * GTDirectory.size() + groundTruth2);
                parameterArray[thresholdingMethods + groundTruth1 * GTDirectory.size() + groundTruth2][1] = extraFractionAveraged / inc;
                parameterArray[thresholdingMethods+ groundTruth1 * GTDirectory.size() + groundTruth2][2] = hddMaxAveraged / inc;
                parameterArray[thresholdingMethods + groundTruth1 * GTDirectory.size() + groundTruth2][3] = hddSumAveraged / inc;
                parameterArray[thresholdingMethods+ groundTruth1 * GTDirectory.size() + groundTruth2][4] = overlapIndexAveraged / inc;
                parameterArray[thresholdingMethods + groundTruth1 * GTDirectory.size() + groundTruth2][5] = similarityIndexAveraged / inc;

            }

        }
            return parameterArray;
    }

    private Double[][] GroundTruthComparison_TwoThreshold(Double[][] parameterArray) {

        SegmentationComparison ExtractParametersObject = new SegmentationComparison();

        ArrayList<String> imageArray = getImageArray(inputDirectory);

        for (int groundTruth1 = 0; groundTruth1 < GTDirectory.size(); groundTruth1++) {
            for (int groundTruth2 = 0; groundTruth2 < GTDirectory.size(); groundTruth2++) {

                IJ.log(Integer.toString(groundTruth1) + ", " + Integer.toString(groundTruth2));

                double extraFractionAveraged = 0;
                double hddMaxAveraged = 0;
                double hddSumAveraged = 0;
                double overlapIndexAveraged = 0;
                double similarityIndexAveraged = 0;
                double inc = 0;

                for (int imagesInArray = 0; imagesInArray < imageArray.size(); imagesInArray++) {

                    ArrayList<Roi[]> GTRoisList = new ArrayList<Roi[]>();
                    for (int i = 0; i < GTDirectory.size(); i++) {
                        String[] roiSources = new File(GTDirectory.get(i)).list();
                        Arrays.sort(roiSources);
                        GTRoisList.add(GetGTRois(GTDirectory.get(i) + roiSources[imagesInArray]));

                    }
                    ExtractParametersObject.exec(GTRoisList.get(groundTruth2), GTRoisList.get(groundTruth1));

                    double[] extraFractionImageArray = ExtractParametersObject.getExtraFractionImageArray();
                    double[] hddMaxImageArray = ExtractParametersObject.getHddMaxImageArray();
                    double[] hddSumImageArray = ExtractParametersObject.getHddSumImageArray();
                    double[] overlapIndexImageArray = ExtractParametersObject.getOverlapIndexImageArray();
                    double[] similarityIndexImageArray = ExtractParametersObject.getSimilarityIndexImageArray();

                    for (int cellCount = 0; cellCount < extraFractionImageArray.length; cellCount++) {
                        extraFractionAveraged += extraFractionImageArray[cellCount];
                        hddMaxAveraged += hddMaxImageArray[cellCount];
                        hddSumAveraged += hddSumImageArray[cellCount];
                        overlapIndexAveraged += overlapIndexImageArray[cellCount];
                        similarityIndexAveraged += similarityIndexImageArray[cellCount];

                        inc += 1;

                    }

                }
                parameterArray[(thresholdingMethods * thresholdingMethods) + groundTruth1 * GTDirectory.size() + groundTruth2][0] = (double) ((thresholdingMethods * thresholdingMethods) + groundTruth1 * GTDirectory.size() + groundTruth2);
                parameterArray[(thresholdingMethods * thresholdingMethods) + groundTruth1 * GTDirectory.size() + groundTruth2][1] = extraFractionAveraged / inc;
                parameterArray[(thresholdingMethods * thresholdingMethods) + groundTruth1 * GTDirectory.size() + groundTruth2][2] = hddMaxAveraged / inc;
                parameterArray[(thresholdingMethods * thresholdingMethods) + groundTruth1 * GTDirectory.size() + groundTruth2][3] = hddSumAveraged / inc;
                parameterArray[(thresholdingMethods * thresholdingMethods) + groundTruth1 * GTDirectory.size() + groundTruth2][4] = overlapIndexAveraged / inc;
                parameterArray[(thresholdingMethods * thresholdingMethods) + groundTruth1 * GTDirectory.size() + groundTruth2][5] = similarityIndexAveraged / inc;

            }

        }

        return parameterArray;
    }

        private Double[][] OneThresholdingComparison(Double[][] parameterArray) {
        SegmentationComparison ExtractParametersObject = new SegmentationComparison();
        ArrayList<String> imageArray = getImageArray(inputDirectory);

        for (int globalThreshold = 1; globalThreshold <= thresholdingMethods; globalThreshold++) {
            globalThresholdMethod=globalThreshold;
            localThresholdMethod=-1;

                IJ.log(Integer.toString(globalThreshold) + ", ");

                Segmentation SegmentationObject = new Segmentation(numberThreshold,globalThresholdMethod, localThresholdMethod, smoothing, watershed, dilations, blackBackground);
                double extraFractionAveraged = 0;
                double hddMaxAveraged = 0;
                double hddSumAveraged = 0;
                double overlapIndexAveraged = 0;
                double similarityIndexAveraged = 0;
                double inc = 0;

                for (int imagesInArray = 0; imagesInArray < imageArray.size(); imagesInArray++) {

                    ImagePlus imp = IJ.openImage(inputDirectory + imageArray.get(imagesInArray));
                    SegmentationObject.exec(imp);
                    Roi[] roiArray = SegmentationObject.getRoiArray();

                    ArrayList<Roi[]> GTRoisList = new ArrayList<Roi[]>();
                    for (int i = 0; i < GTDirectory.size(); i++) {
                        String[] roiSources = new File(GTDirectory.get(i)).list();
                        Arrays.sort(roiSources);
                        GTRoisList.add(GetGTRois(GTDirectory.get(i) + roiSources[imagesInArray]));
                    }

                    for (int groundTruth = 0; groundTruth < GTDirectory.size(); groundTruth++) {
                        double extraFractionAveragedLocal = 0;
                        double hddMaxAveragedLocal = 0;
                        double hddSumAveragedLocal = 0;
                        double overlapIndexAveragedLocal = 0;
                        double similarityIndexAveragedLocal = 0;

                        ExtractParametersObject.exec(roiArray, GTRoisList.get(groundTruth));

                        double[] extraFractionImageArray = ExtractParametersObject.getExtraFractionImageArray();
                        double[] hddMaxImageArray = ExtractParametersObject.getHddMaxImageArray();
                        double[] hddSumImageArray = ExtractParametersObject.getHddSumImageArray();
                        double[] overlapIndexImageArray = ExtractParametersObject.getOverlapIndexImageArray();
                        double[] similarityIndexImageArray = ExtractParametersObject.getSimilarityIndexImageArray();

                        for (int cellCount = 0; cellCount < extraFractionImageArray.length; cellCount++) {
                            extraFractionAveraged += extraFractionImageArray[cellCount];
                            hddMaxAveraged += hddMaxImageArray[cellCount];
                            hddSumAveraged += hddSumImageArray[cellCount];
                            overlapIndexAveraged += overlapIndexImageArray[cellCount];
                            similarityIndexAveraged += similarityIndexImageArray[cellCount];
                            
                            extraFractionAveragedLocal += extraFractionImageArray[cellCount];
                            hddMaxAveragedLocal += hddMaxImageArray[cellCount];
                            hddSumAveragedLocal += hddSumImageArray[cellCount];
                            overlapIndexAveragedLocal += overlapIndexImageArray[cellCount];
                            similarityIndexAveragedLocal += similarityIndexImageArray[cellCount];
                            inc += 1;
                        }
                        System.out.println(extraFractionAveragedLocal/roiArray.length+ ", " + hddMaxAveragedLocal/roiArray.length + ", " +  hddSumAveragedLocal/roiArray.length + ", " + overlapIndexAveragedLocal/roiArray.length + ", " + similarityIndexAveragedLocal/roiArray.length);
                        //System.out.println("");
                    }

                }
                IJ.log(extraFractionAveraged/inc + ", " + hddMaxAveraged/inc + ", " +  hddSumAveraged/inc + ", " + overlapIndexAveraged/inc + ", " + similarityIndexAveraged/inc);
                parameterArray[globalThreshold-1][0] = (double) (globalThreshold - 1);
                parameterArray[globalThreshold-1][1] = extraFractionAveraged / inc;
                parameterArray[globalThreshold-1][2] = hddMaxAveraged / inc;
                parameterArray[globalThreshold-1][3] = hddSumAveraged / inc;
                parameterArray[globalThreshold-1][4] = overlapIndexAveraged / inc;
                parameterArray[globalThreshold-1][5] = similarityIndexAveraged / inc;
            }
        return parameterArray;

    }
    
    private Double[][] TwoThresholdingComparison(Double[][] parameterArray) {
        SegmentationComparison ExtractParametersObject = new SegmentationComparison();

        ArrayList<String> imageArray = getImageArray(inputDirectory);

        for (int globalThreshold = 1; globalThreshold <= thresholdingMethods; globalThreshold++) {
            globalThresholdMethod=globalThreshold;

            for (int localThreshold = 1; localThreshold <= thresholdingMethods; localThreshold++) {
            localThresholdMethod=localThreshold;

                IJ.log(Integer.toString(globalThreshold) + ", " + Integer.toString(localThreshold));

                Segmentation SegmentationObject = new Segmentation(numberThreshold,globalThresholdMethod, localThresholdMethod, smoothing, watershed, dilations, blackBackground);
                double extraFractionAveraged = 0;
                double hddMaxAveraged = 0;
                double hddSumAveraged = 0;
                double overlapIndexAveraged = 0;
                double similarityIndexAveraged = 0;
                double inc = 0;

                for (int imagesInArray = 0; imagesInArray < imageArray.size(); imagesInArray++) {

                    ImagePlus imp = IJ.openImage(inputDirectory + imageArray.get(imagesInArray));
                    SegmentationObject.exec(imp);
                    Roi[] roiArray = SegmentationObject.getRoiArray();

                    ArrayList<Roi[]> GTRoisList = new ArrayList<Roi[]>();
                    for (int i = 0; i < GTDirectory.size(); i++) {
                        String[] roiSources = new File(GTDirectory.get(i)).list();
                        Arrays.sort(roiSources);
                        GTRoisList.add(GetGTRois(GTDirectory.get(i) + roiSources[imagesInArray]));
                    }

                    for (int groundTruth = 0; groundTruth < GTDirectory.size(); groundTruth++) {
                        double extraFractionAveragedLocal = 0;
                        double hddMaxAveragedLocal = 0;
                        double hddSumAveragedLocal = 0;
                        double overlapIndexAveragedLocal = 0;
                        double similarityIndexAveragedLocal = 0;

                        ExtractParametersObject.exec(roiArray, GTRoisList.get(groundTruth));

                        double[] extraFractionImageArray = ExtractParametersObject.getExtraFractionImageArray();
                        double[] hddMaxImageArray = ExtractParametersObject.getHddMaxImageArray();
                        double[] hddSumImageArray = ExtractParametersObject.getHddSumImageArray();
                        double[] overlapIndexImageArray = ExtractParametersObject.getOverlapIndexImageArray();
                        double[] similarityIndexImageArray = ExtractParametersObject.getSimilarityIndexImageArray();

                        for (int cellCount = 0; cellCount < extraFractionImageArray.length; cellCount++) {
                            extraFractionAveraged += extraFractionImageArray[cellCount];
                            hddMaxAveraged += hddMaxImageArray[cellCount];
                            hddSumAveraged += hddSumImageArray[cellCount];
                            overlapIndexAveraged += overlapIndexImageArray[cellCount];
                            similarityIndexAveraged += similarityIndexImageArray[cellCount];
                            
                            extraFractionAveragedLocal += extraFractionImageArray[cellCount];
                            hddMaxAveragedLocal += hddMaxImageArray[cellCount];
                            hddSumAveragedLocal += hddSumImageArray[cellCount];
                            overlapIndexAveragedLocal += overlapIndexImageArray[cellCount];
                            similarityIndexAveragedLocal += similarityIndexImageArray[cellCount];
                            inc += 1;
                        }
                        System.out.println(extraFractionAveragedLocal/roiArray.length+ ", " + hddMaxAveragedLocal/roiArray.length + ", " +  hddSumAveragedLocal/roiArray.length + ", " + overlapIndexAveragedLocal/roiArray.length + ", " + similarityIndexAveragedLocal/roiArray.length);
                        //System.out.println("");
                    }

                }
                IJ.log(extraFractionAveraged/inc + ", " + hddMaxAveraged/inc + ", " +  hddSumAveraged/inc + ", " + overlapIndexAveraged/inc + ", " + similarityIndexAveraged/inc);
                parameterArray[(globalThreshold - 1) * thresholdingMethods + (localThreshold - 1)][0] = (double) ((globalThreshold - 1) * thresholdingMethods + (localThreshold - 1));
                parameterArray[(globalThreshold - 1) * thresholdingMethods + (localThreshold - 1)][1] = extraFractionAveraged / inc;
                parameterArray[(globalThreshold - 1) * thresholdingMethods + (localThreshold - 1)][2] = hddMaxAveraged / inc;
                parameterArray[(globalThreshold - 1) * thresholdingMethods + (localThreshold - 1)][3] = hddSumAveraged / inc;
                parameterArray[(globalThreshold - 1) * thresholdingMethods + (localThreshold - 1)][4] = overlapIndexAveraged / inc;
                parameterArray[(globalThreshold - 1) * thresholdingMethods + (localThreshold - 1)][5] = similarityIndexAveraged / inc;
            }

        }
        return parameterArray;

    }

    private Double[][] NoiseComparison(Double[][] parameterArray, ArrayList<String> imageArray) {
        SegmentationComparison ExtractParametersObject = new SegmentationComparison();
        String[] GT = new File(GTDirectory.get(0)).list();
        int totalImages = imageArray.size();
        int totalNrNoise = imageArray.size() / GT.length;
        Segmentation SegmentationObject = new Segmentation(numberThreshold,globalThresholdMethod, localThresholdMethod, smoothing, watershed, dilations, blackBackground);
        IJ.log("NrNoise, Extra fraction, Hausdorff distance, Averaged HD, Overlap index, Similarity index");

        for (int NrNoise = 0; NrNoise < totalNrNoise; NrNoise++) {
            String name = imageArray.get(NrNoise);
            String noise = name.substring(6);
            //IJ.log(noise + "");

            double extraFractionAveraged = 0;
            double hddMaxAveraged = 0;
            double hddSumAveraged = 0;
            double overlapIndexAveraged = 0;
            double similarityIndexAveraged = 0;
            double inc = 0;
            int nrGtImage = 0;

            for (int imagesInArray = NrNoise; imagesInArray < imageArray.size(); imagesInArray = imagesInArray + totalNrNoise) {
                ImagePlus imp = IJ.openImage(inputDirectory + imageArray.get(imagesInArray));
                //imp.show();
                SegmentationObject.exec(imp);
                Roi[] roiArray = SegmentationObject.getRoiArray();
                if (roiArray.length == 0) {
                    System.out.println(imp.getTitle() + ": no ROIs found");

                } else {
                    Overlay overlay = new Overlay();
                    getColor gC = new getColor();
                    for (int i = 0; i < roiArray.length; i++) {
                        Color color = gC.exec(i);
                        roiArray[i].setStrokeColor(color);
                        overlay.add(roiArray[i]);
                    }
                    imp.setOverlay(overlay);
                    IJ.save(imp, "/Users/marliesverschuuren/Desktop/Result_Noise/" + imp.getTitle() + ".tiff");
                }

                double extraFractionImage = 0;
                double hddMaxImage = 0;
                double hddSumImage = 0;
                double overlapIndexImage = 0;
                double similarityIndexImage = 0;
                double incImage=0;

                ArrayList<Roi[]> GTRoisList = new ArrayList<Roi[]>();
                for (int i = 0; i < GTDirectory.size(); i++) {
                    String[] roiSources = new File(GTDirectory.get(i)).list();
                    Arrays.sort(roiSources);
                    GTRoisList.add(GetGTRois(GTDirectory.get(i) + roiSources[nrGtImage]));
                }

                for (int groundTruth = 0; groundTruth < GTDirectory.size(); groundTruth++) {

                    ExtractParametersObject.exec(roiArray, GTRoisList.get(groundTruth));

                    double[] extraFractionImageArray = ExtractParametersObject.getExtraFractionImageArray();
                    double[] hddMaxImageArray = ExtractParametersObject.getHddMaxImageArray();
                    double[] hddSumImageArray = ExtractParametersObject.getHddSumImageArray();
                    double[] overlapIndexImageArray = ExtractParametersObject.getOverlapIndexImageArray();
                    double[] similarityIndexImageArray = ExtractParametersObject.getSimilarityIndexImageArray();

                    for (int cellCount = 0; cellCount < extraFractionImageArray.length; cellCount++) {
                        extraFractionImage += extraFractionImageArray[cellCount];
                        hddMaxImage += hddMaxImageArray[cellCount];
                        hddSumImage += hddSumImageArray[cellCount];
                        overlapIndexImage += overlapIndexImageArray[cellCount];
                        similarityIndexImage += similarityIndexImageArray[cellCount];
                        
                        incImage+=1;
                    }                    
                    for (int cellCount = 0; cellCount < extraFractionImageArray.length; cellCount++) {
                        extraFractionAveraged += extraFractionImageArray[cellCount];
                        hddMaxAveraged += hddMaxImageArray[cellCount];
                        hddSumAveraged += hddSumImageArray[cellCount];
                        overlapIndexAveraged += overlapIndexImageArray[cellCount];
                        similarityIndexAveraged += similarityIndexImageArray[cellCount];

                        inc += 1;
                    }
                }
                double extraFractionImageAveraged = extraFractionImage/incImage;
                double hddMaxImageAveraged = hddMaxImage/incImage;
                double hddSumImageAveraged = hddSumImage/incImage;
                double overlapIndexImageAveraged = overlapIndexImage/incImage;
                double similarityIndexImageAveraged = similarityIndexImage/incImage;
                
                IJ.log(imageArray.get(imagesInArray)+ ", " + extraFractionImageAveraged + ", " + hddMaxImageAveraged + ", " + hddSumImageAveraged + ", " + overlapIndexImageAveraged+ ", " + similarityIndexImageAveraged +"");
                nrGtImage++;
            }
            parameterArray[NrNoise][0] = (double) (NrNoise);
            parameterArray[NrNoise][1] = extraFractionAveraged / inc;
            parameterArray[NrNoise][2] = hddMaxAveraged / inc;
            parameterArray[NrNoise][3] = hddSumAveraged / inc;
            parameterArray[NrNoise][4] = overlapIndexAveraged / inc;
            parameterArray[NrNoise][5] = similarityIndexAveraged / inc;

            //Print array with the parameter score of each thresholding method
            IJ.log(noise + ", " + parameterArray[NrNoise][1].toString() + ", " + parameterArray[NrNoise][2].toString() + ", " + parameterArray[NrNoise][3].toString() + ", " + parameterArray[NrNoise][4].toString() + ", " + parameterArray[NrNoise][5].toString());
        }

        return parameterArray;

    }
    
    private Double[] GroundTruthComparison_NegCtrl() {

        SegmentationComparisonNegCtrl ComparisonNegCtrl = new SegmentationComparisonNegCtrl();
        String[] roiSources = new File(GTDirectory.get(0)).list();
        Arrays.sort(roiSources);
        ArrayList<Roi> roiList = new ArrayList<Roi>();
        ArrayList<Roi[]> GTRoisList = new ArrayList<Roi[]>();
        for (int i=0; i<roiSources.length; i++){
            GTRoisList.add(GetGTRois(GTDirectory.get(0) + roiSources[i]));
            Roi [] tempory = GTRoisList.get(i);
            for(int j=0; j<tempory.length;j++){
                roiList.add(tempory[j]);
            }
        }
        
        ComparisonNegCtrl.exec(roiList);
        double extraFractionAveraged = 0;
        double hddMaxAveraged = 0;
        double hddSumAveraged = 0;
        double overlapIndexAveraged = 0;
        double similarityIndexAveraged = 0;
        double inc = 0;

        double[] extraFractionImageArray = ComparisonNegCtrl.getExtraFractionImageArray();
        double[] hddMaxImageArray = ComparisonNegCtrl.getHddMaxImageArray();
        double[] hddSumImageArray = ComparisonNegCtrl.getHddSumImageArray();
        double[] overlapIndexImageArray = ComparisonNegCtrl.getOverlapIndexImageArray();
        double[] similarityIndexImageArray = ComparisonNegCtrl.getSimilarityIndexImageArray();

        for (int cellCount = 0; cellCount < extraFractionImageArray.length; cellCount++) {
            extraFractionAveraged += extraFractionImageArray[cellCount];
                        hddMaxAveraged += hddMaxImageArray[cellCount];
                        hddSumAveraged += hddSumImageArray[cellCount];
                        overlapIndexAveraged += overlapIndexImageArray[cellCount];
                        similarityIndexAveraged += similarityIndexImageArray[cellCount];

                        inc += 1;
                    }
        Double [] averagedParameterArray = new Double [5]; 
        averagedParameterArray [0] = extraFractionAveraged / inc;
        averagedParameterArray [1] = hddMaxAveraged / inc;
        averagedParameterArray [2] = hddSumAveraged / inc;
        averagedParameterArray [3] = overlapIndexAveraged / inc;
        averagedParameterArray [4] = similarityIndexAveraged / inc;
        
        return averagedParameterArray;
    }


    private Double[][] SortArray(Double[][] parameterArray, final int i) {
        Arrays.sort(parameterArray, new Comparator<Double[]>() {
            public int compare(Double[] int1, Double[] int2) {
                Double numOfKeys1 = int1[i];
                Double numOfKeys2 = int2[i];
                return numOfKeys1.compareTo(numOfKeys2);
            }
        });
        return parameterArray;
    }

    private Roi[] GetGTRois(String groundThruthPath) {

        ArrayList<Roi> roiList = new ArrayList<Roi>();
        ZipInputStream in = null;
        ByteArrayOutputStream out;
        //int nRois = 0; 
        try {
            in = new ZipInputStream(new FileInputStream(groundThruthPath));
            byte[] buf = new byte[1024];
            int len;
            ZipEntry entry = in.getNextEntry();
            while (entry != null) {
                String name = entry.getName();
                if (name.endsWith(".roi")) {
                    out = new ByteArrayOutputStream();
                    while ((len = in.read(buf)) > 0) {
                        out.write(buf, 0, len);
                    }
                    out.close();
                    byte[] bytes = out.toByteArray();
                    RoiDecoder rd = new RoiDecoder(bytes, name);
                    Roi roi = rd.getRoi();
                    if (roi != null) {
                        roiList.add(roi);
                        //nRois++;
                    }
                }
                entry = in.getNextEntry();
            }
            in.close();
        } catch (IOException e) {
            System.out.println(e.toString());
        }
        Roi[] roiArrayGT = new Roi[roiList.size()];
        roiArrayGT = roiList.toArray(roiArrayGT);
        return roiArrayGT;

    }

    private void getAll(InitialConfiguration InitialConfigurationObject) {
        buttonNames = InitialConfigurationObject.getButtonNames();
        dilations = InitialConfigurationObject.getDilations();
        globalThresholdMethod = InitialConfigurationObject.getGlobalThresholdMethod();
        inputDirectory = InitialConfigurationObject.getInputDirectory();
        localThresholdMethod = InitialConfigurationObject.getLocalThresholdMethod();
        outputDirectory = InitialConfigurationObject.getOutputDirectory();
        functionality = InitialConfigurationObject.getFunctionality();
        GTDirectory = InitialConfigurationObject.getGTDirectory();
        numberThreshold=InitialConfigurationObject.getNumberThreshold();
        watershed = InitialConfigurationObject.getWatershed();
        smoothing = InitialConfigurationObject.getSmoothing();

    }

    private ArrayList<String> getImageArray(String directoryName) {
        //Put all the names of the image-files in String[] + sort
        String[] fileArray = new File(directoryName).list();
        Arrays.sort(fileArray);

        //Check the extensions of the files in fileArray and put the file-names in imageArray if correct
        ArrayList<String> imageArray = new ArrayList<String>();
        for (int i = 0; i < fileArray.length; i++) {
            if (fileArray[i].indexOf(".tif") > 0 || fileArray[i].indexOf(".dcm") > 0 || fileArray[i].indexOf(".fits") > 0
                    || fileArray[i].indexOf(".fit") > 0 || fileArray[i].indexOf(".fts") > 0 || fileArray[i].indexOf(".pgm") > 0
                    || fileArray[i].indexOf(".jpg") > 0 || fileArray[i].indexOf(".jpeg") > 0 || fileArray[i].indexOf(".bmp") > 0) {

                imageArray.add(fileArray[i]);
            }
        }
        return imageArray;
    }

    private void Stop() {
        System.exit(0);
    }

    //*    
    public static void main(final String... args) {
        new ij.ImageJ();
        new Marlies_Plugin().run("");
    }
    //*/

}
